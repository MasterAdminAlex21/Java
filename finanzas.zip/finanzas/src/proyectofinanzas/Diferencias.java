/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinanzas;
import java.util.ArrayList;
import proyectofinanzas.beans.Cuenta;
import proyectofinanzas.beans.GetCuentaName;
import proyectofinanzas.beans.Reporte;

/**
 *
 * @author Plata
 */
public class Diferencias extends javax.swing.JFrame {

    /**
     * Creates new form Diferencias
     */
    public Diferencias(Reporte rep1,Reporte rep2) {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Método de diferencias");
        initComponents();
        setReporte1(rep1);
        setReporte2(rep2);
        setDiferencias(rep2);
    }
    
       
    private Reporte rep1;
    private Reporte rep2;
    
    
    private final void setReporte1(Reporte rep1){
        this.rep1=rep1;
        
        double totalActivos = rep1.getTotalActivos();
        double totalP = rep1.getTotalPasivos();
        double totalO = rep1.getTotalOtros();
        
        
        { // Caja
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Caja");
            double totalC = c.getTotal();
            double cajaP = ((totalC*100)/totalActivos);
            txtCaja1.setText("$"+totalC);
            
        }
        
        { // Bancos
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Bancos");
            Cuenta d = GetCuentaName.getCuentaName(rep1.getDiferencias(), "DBancos");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtBancos1.setText("$"+totalC);
            
        }
        { //Almacen
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Almacen");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtAlmacen1.setText("$"+totalC);
            
        }
        
        { // Clientes
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Clientes");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtClientes1.setText("$"+totalC);
            
        }
        
        { // Deudores
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Deudores");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtDeudores1.setText("$"+totalC);
            
        }
        { // Documentos por cobrar
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Documentos por cobrar");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtDocumentosporcobrar1.setText("$"+totalC);
            
        }
        { // Terrenos
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Terrenos");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtTerrenos1.setText("$"+totalC);
            
        }
        { // Edificios
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Edificios");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEdificios1.setText("$"+totalC);
            
        }
        { // Mobiliairo
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Mobiliario");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtMobiliario1.setText("$"+totalC);
            
        }
        { // Equipo de reparto
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Equipo de reparto");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEquipodereparto1.setText("$"+totalC);
            
        }
        { // Equipo de transporte
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Equipo de transporte");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEquipodetransporte1.setText("$"+totalC);
            
        }
        { // Equipo de computo
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Equipo de computo");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEquipodecomputo1.setText("$"+totalC);
            
        }
        { // Gastos de instalacion
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Gastos de instalacion");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtGastosdeinstalacion1.setText("$"+totalC);
            
        }
        { // Gastos de organizacion
            Cuenta c = GetCuentaName.getCuentaName(rep1.getActivos(), "Gastos de organizacion");
            
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtGastosdeorganizacion1.setText("$"+totalC);
            
        }
        
        { // Proovedores
            Cuenta c = GetCuentaName.getCuentaName(rep1.getPasivos(), "Proovedores");
            
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtProovedores1.setText("$"+totalC);
            
        }
        { // Acreedores
            Cuenta c = GetCuentaName.getCuentaName(rep1.getPasivos(), "Acreedores");
            
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtAcreedores1.setText("$"+totalC);
            
        }
        { // Documentos por pagar
            Cuenta c = GetCuentaName.getCuentaName(rep1.getPasivos(), "Documentos por pagar");
            
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtDocumentosporpagar1.setText("$"+totalC);
            
        }
        { // Acreedores hipotecarios
            Cuenta c = GetCuentaName.getCuentaName(rep1.getPasivos(), "Acreedores hipotecarios");
            
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtAcreedoreshipotecarios1.setText("$"+totalC);
            
        }
        { // Documentos por pagar largo plazo
            Cuenta c = GetCuentaName.getCuentaName(rep1.getPasivos(), "Documentos por pagar largo plazo");
            
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtDocumentoslargoplazo1.setText("$"+totalC);
            
        }
        { // Capital Social
            Cuenta c = GetCuentaName.getCuentaName(rep1.getOtros(), "Capital social");
            
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalO;
            txtCapitalsocial1.setText("$"+totalC);
            
        }
        
        { // Utilidad neta
            Cuenta c = GetCuentaName.getCuentaName(rep1.getOtros(), "Utilidad neta");
            
            double totalC = getUtilidadNeta(rep1);
            double cajaP = (totalC*100)/totalO;
            txtUtilidadneta1.setText("$"+totalC);
            
        }
        {//Activo circulante
            Cuenta c = GetCuentaName.getCuentaName(rep1.getOcultas(), "Activo circulante");
            double totalC = getActivoCirculante(rep1);
            double cajaP = (totalC*100)/totalActivos;
            txtActivocirculante1.setText("$"+totalC);
        }
        
        {//Activo fijo
            Cuenta c = GetCuentaName.getCuentaName(rep1.getOcultas(), "Activo fijo");
            double totalC = getActivoFijo(rep1);
            double cajaP = (totalC*100)/totalActivos;
            txtActivofijo1.setText("$"+totalC);
        }
        
        {//Activo diferido
            Cuenta c = GetCuentaName.getCuentaName(rep1.getOcultas(), "Activo diferido");
            double totalC = getActivoDiferido(rep1);
            double cajaP = (totalC*100)/totalActivos;
            txtActivodiferido1.setText("$"+totalC);
        }
        
        {//Pasivo circulante
            Cuenta c = GetCuentaName.getCuentaName(rep1.getOcultas(), "Pasivo circulante");
            double totalC = getPasivoCirculante(rep1);
            double cajaP = (totalC*100)/totalP;
            txtPasivocirculante1.setText("$"+totalC);
        }
        
        {//Pasivo fijo
            Cuenta c = GetCuentaName.getCuentaName(rep1.getOcultas(), "Pasivo fijo");
            double totalC = getPasivoFijo(rep1);
            double cajaP = (totalC*100)/totalP;
            txtPasivofijo1.setText("$"+totalC);
        }
        
        {//Total activos
            txtTotalactivo1.setText("$"+rep1.getTotalActivos());
        }
        
        {//Total pasivos
            double totalC = rep1.getTotalPasivos();
            double cajaP = (totalC*100)/totalActivos;
            txtTotalpasivo1.setText("$"+totalC);
        }       
        
        {//Total capital
            double totalC = rep1.getTotalOtros();
            double cajaP = (totalC*100)/totalActivos;
            txtTotalcapital1.setText("$"+totalC);
        }
        
    }
    
    
    
     private final void setReporte2 (Reporte rep2){
        this.rep2=rep2;
        
        double totalActivos = rep2.getTotalActivos();
        double totalP = rep2.getTotalPasivos();
        double totalO = rep2.getTotalOtros();
        
        
        { // Caja
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Caja");
            double totalC = c.getTotal();
            double cajaP = ((totalC*100)/totalActivos);
            txtCaja2.setText("$"+totalC);
        }
        
        { // Bancos
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Bancos");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtBancos2.setText("$"+totalC);
        }
        { //Almacen
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Caja");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtAlmacen2.setText("$"+totalC);
        }
        
        { // Clientes
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Clientes");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtClientes2.setText("$"+totalC);
        }
        
        { // Deudores
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Deudores");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtDeudores2.setText("$"+totalC);
        }
        { // Documentos por cobrar
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Documentos por cobrar");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtDocumentosporcobrar2.setText("$"+totalC);
        }
        { // Terrenos
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Terrenos");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtTerrenos2.setText("$"+totalC);
        }
        { // Edificios
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Edificios");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEdificios2.setText("$"+totalC);
        }
        { // Mobiliairo
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Mobiliario");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtMobiliario2.setText("$"+totalC);
        }
        { // Equipo de reparto
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Equipo de reparto");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEquipodereparto2.setText("$"+totalC);
        }
        { // Equipo de transporte
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Equipo de transporte");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEquipodetransporte2.setText("$"+totalC);
        }
        { // Equipo de computo
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Equipo de computo");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEquipodecomputo2.setText("$"+totalC);
        }
        { // Gastos de instalacion
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Gastos de instalacion");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtGastosdeinstalacion1.setText("$"+totalC);
        }
        { // Gastos de organizacion
            Cuenta c = GetCuentaName.getCuentaName(rep2.getActivos(), "Gastos de organizacion");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtGastosdeorganizacion2.setText("$"+totalC);
        }
        
        { // Proovedores
            Cuenta c = GetCuentaName.getCuentaName(rep2.getPasivos(), "Proovedores");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtProovedores2.setText("$"+totalC);
        }
        { // Acreedores
            Cuenta c = GetCuentaName.getCuentaName(rep2.getPasivos(), "Acreedores");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtAcreedores2.setText("$"+totalC);
        }
        { // Documentos por pagar
            Cuenta c = GetCuentaName.getCuentaName(rep2.getPasivos(), "Documentos por pagar");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtDocumentosporpagar2.setText("$"+totalC);
        }
        { // Acreedores hipotecarios
            Cuenta c = GetCuentaName.getCuentaName(rep2.getPasivos(), "Acreedores hipotecarios");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtAcreedoreshipotecarios2.setText("$"+totalC);
        }
        { // Documentos por pagar largo plazo
            Cuenta c = GetCuentaName.getCuentaName(rep2.getPasivos(), "Documentos por pagar largo plazo");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtDocumentoslargoplazo2.setText("$"+totalC);
        }
        { // Capital Social
            Cuenta c = GetCuentaName.getCuentaName(rep2.getOtros(), "Capital social");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalO;
            txtCapitalsocial2.setText("$"+totalC);
        }
        
        { // Utilidad neta
            Cuenta c = GetCuentaName.getCuentaName(rep2.getOtros(), "Utilidad neta");
            double totalC = getUtilidadNeta(rep2);
            double cajaP = (totalC*100)/totalO;
            txtUtilidadneta2.setText("$"+totalC);
        }
        {//Activo circulante
            Cuenta c = GetCuentaName.getCuentaName(rep2.getOcultas(), "Activo circulante");
            double totalC = getActivoCirculante(rep2);
            double cajaP = (totalC*100)/totalActivos;
            txtActivocirculante2.setText("$"+totalC);
        }
        
        {//Activo fijo
            Cuenta c = GetCuentaName.getCuentaName(rep2.getOcultas(), "Activo fijo");
            double totalC = getActivoFijo(rep2);
            double cajaP = (totalC*100)/totalActivos;
            txtActivofijo2.setText("$"+totalC);
        }
        
        {//Activo diferido
            Cuenta c = GetCuentaName.getCuentaName(rep2.getOcultas(), "Activo diferido");
            double totalC = getActivoDiferido(rep2);
            double cajaP = (totalC*100)/totalActivos;
            txtActivodiferido2.setText("$"+totalC);
        }
        
        {//Pasivo circulante
            Cuenta c = GetCuentaName.getCuentaName(rep2.getOcultas(), "Pasivo circulante");
            double totalC = getPasivoCirculante(rep2);
            double cajaP = (totalC*100)/totalP;
            txtPasivocirculante2.setText("$"+totalC);
        }
        
        {//Pasivo fijo
            Cuenta c = GetCuentaName.getCuentaName(rep2.getOcultas(), "Pasivo fijo");
            double totalC = getPasivoFijo(rep2);
            double cajaP = (totalC*100)/totalP;
            txtPasivofijo2.setText("$"+totalC);
        }
        
        {//Total activos
            txtTotalactivo2.setText("$"+rep2.getTotalActivos());
        }
        
        {//Total pasivos
            double totalC = rep2.getTotalPasivos();
            double cajaP = (totalC*100)/totalActivos;
            txtTotalpasivo2.setText("$"+totalC);
        }       
        
        {//Total capital
            double totalC = rep2.getTotalOtros();
            double cajaP = (totalC*100)/totalActivos;
            txtTotalcapital2.setText("$"+totalC);
        }
        
    }
    
    
    
    private double getUtilidadNeta(Reporte r){
        Cuenta v = GetCuentaName.getCuentaName(r.getOtros(), "Ventas");
        Cuenta cv = GetCuentaName.getCuentaName(r.getOtros(), "Costo de ventas");
        Cuenta gv = GetCuentaName.getCuentaName(r.getOtros(), "Gastos de ventas");
        Cuenta ga = GetCuentaName.getCuentaName(r.getOtros(), "Gastos de administracion");
        Cuenta gf = GetCuentaName.getCuentaName(r.getOtros(), "Gastos financieros");
        Cuenta og = GetCuentaName.getCuentaName(r.getOtros(), "Otros gastos");
        Cuenta pf = GetCuentaName.getCuentaName(r.getOtros(), "Productos financieros");
        Cuenta op = GetCuentaName.getCuentaName(r.getOtros(), "Otros productos");
        
        double un = (cv.getTotal(true)+gv.getTotal(true)+
                ga.getTotal(true)+gf.getTotal(true)+og.getTotal(true));
        un=v.getTotal(true)-un;
        un=(pf.getTotal(true)+op.getTotal(true))+un;
        return un;
    }
    
    private double getActivoCirculante (Reporte r){
        Cuenta ca = GetCuentaName.getCuentaName(r.getActivos(), "Caja");
        Cuenta ba = GetCuentaName.getCuentaName(r.getActivos(), "Bancos");
        Cuenta al = GetCuentaName.getCuentaName(r.getActivos(), "Almacen");
        Cuenta cl = GetCuentaName.getCuentaName(r.getActivos(), "Clientes");
        Cuenta de = GetCuentaName.getCuentaName(r.getActivos(), "Deudores");
        Cuenta dc = GetCuentaName.getCuentaName(r.getActivos(), "Documentos por cobrar");
        
        double t = (ca.getTotal(false)+ba.getTotal(false)+al.getTotal(false)+cl.getTotal(false)+de.getTotal(false)+dc.getTotal(false));
        return t;
    }
    
    private double getActivoFijo (Reporte r){
        Cuenta te = GetCuentaName.getCuentaName(r.getActivos(), "Terrenos");
        Cuenta ed = GetCuentaName.getCuentaName(r.getActivos(), "Edificios");
        Cuenta mo = GetCuentaName.getCuentaName(r.getActivos(), "Mobiliario");
        Cuenta er = GetCuentaName.getCuentaName(r.getActivos(), "Equipo de reparto");
        Cuenta et = GetCuentaName.getCuentaName(r.getActivos(), "Equipo de transporte");
        Cuenta ec = GetCuentaName.getCuentaName(r.getActivos(), "Equipo de computo");
        
        double t = (te.getTotal(false)+ed.getTotal(false)+mo.getTotal(false)+er.getTotal(false)+et.getTotal(false)+ec.getTotal(false));
        return t;
    }
    
    private double getActivoDiferido (Reporte r){
        Cuenta go = GetCuentaName.getCuentaName(r.getActivos(), "Gastos de organizacion");
        Cuenta gi = GetCuentaName.getCuentaName(r.getActivos(), "Gastos de instalacion");
        
        double t = (go.getTotal(false)+gi.getTotal(false));
        return t;
    }
    
    private double getPasivoCirculante (Reporte r){
        Cuenta pr = GetCuentaName.getCuentaName(r.getPasivos(), "Proovedores");
        Cuenta ac = GetCuentaName.getCuentaName(r.getPasivos(), "Acreedores");
        Cuenta dp = GetCuentaName.getCuentaName(r.getPasivos(), "Documentos por pagar");
        
        double t = (pr.getTotal(true)+ac.getTotal(true)+dp.getTotal(true));
        return t;
        
    }
    
    private double getPasivoFijo (Reporte r){
        Cuenta ah = GetCuentaName.getCuentaName(r.getPasivos(), "Acreedores hipotecarios");
        Cuenta dpl = GetCuentaName.getCuentaName(r.getPasivos(), "Documentos por pagar largo plazo");
        
        double t = (ah.getTotal(true)+dpl.getTotal(true));
        return t;
    }
        
    private void setDiferencias(Reporte rep){
        try{
            Cuenta dcaja = GetCuentaName.getCuentaName(rep.getActivos(), "DCaja");
            Cuenta dbancos = GetCuentaName.getCuentaName(rep.getActivos(), "DBancos");
            Cuenta dalmacen = GetCuentaName.getCuentaName(rep.getActivos(), "DAlmacen");
            Cuenta dclientes = GetCuentaName.getCuentaName(rep.getActivos(), "DClientes");
            Cuenta ddeudores = GetCuentaName.getCuentaName(rep.getActivos(), "DDeudores");
            Cuenta ddocumentosporcobrar = GetCuentaName.getCuentaName(rep.getActivos(), "DDocumentos por pagar");
            Cuenta dterrenos = GetCuentaName.getCuentaName(rep.getActivos(), "DTerrenos");
            Cuenta dedificios = GetCuentaName.getCuentaName(rep.getActivos(), "DEdificios");
            Cuenta dmobiliario = GetCuentaName.getCuentaName(rep.getActivos(), "DMobiliario");
            Cuenta dequipodereparto = GetCuentaName.getCuentaName(rep.getActivos(), "DEquipo de reparto");
            Cuenta dequipodetransporte = GetCuentaName.getCuentaName(rep.getActivos(), "DEquipo de transporte");
            Cuenta dequipodecomputo = GetCuentaName.getCuentaName(rep.getActivos(), "DEquipo de computo");
            Cuenta dgastosdeinstalacion = GetCuentaName.getCuentaName(rep.getActivos(), "DGastos de instalacion");
            Cuenta dgastosdeorganizacion = GetCuentaName.getCuentaName(rep.getActivos(), "DGastos de organizacion");
            
            Cuenta dproovedores = GetCuentaName.getCuentaName(rep.getActivos(), "DProovedores");
            Cuenta dacreedores = GetCuentaName.getCuentaName(rep.getActivos(), "DAcreedores");
            Cuenta ddocumentosporpagar = GetCuentaName.getCuentaName(rep.getActivos(), "DDocumentos por pagar");
            Cuenta dacreedoreshipotecarios = GetCuentaName.getCuentaName(rep.getActivos(), "DAcreedores hipotecarios");
            Cuenta ddocumentosporpagarlargoplazo = GetCuentaName.getCuentaName(rep.getActivos(), "DDocumentos por pagar largo plazo");
           
            Cuenta dcapitalsocial = GetCuentaName.getCuentaName(rep.getActivos(), "DCapital social");
            Cuenta dutilidadneta = GetCuentaName.getCuentaName(rep.getActivos(), "DUtilidad neta");
            txtCajadiferencia.setText(""+((Double.parseDouble(txtCaja1.getText()))-(Double.parseDouble(txtCaja2.getText()))));
            txtBancosdiferencia.setText(""+(Double.parseDouble(txtBancos1.getText())-Double.parseDouble(txtBancos2.getText())));
            txtAlmacendiferencia.setText(""+(Double.parseDouble(txtAlmacen1.getText())-Double.parseDouble(txtAlmacen2.getText())));
            txtClientesdiferencia.setText(""+(Double.parseDouble(txtClientes1.getText())-Double.parseDouble(txtClientes2.getText())));
            txtDeudoresdiferencia.setText(""+(Double.parseDouble(txtDeudores1.getText())-Double.parseDouble(txtDeudores2.getText())));
            txtDocumentosporcobrardiferencia.setText(""+(Double.parseDouble(txtDocumentosporcobrar1.getText())-Double.parseDouble(txtDocumentosporcobrar2.getText())));
            txtTerrenosdiferencia.setText(""+(Double.parseDouble(txtTerrenos1.getText())-Double.parseDouble(txtTerrenos2.getText())));
            txtEdificiosdiferencia.setText(""+(Double.parseDouble(txtEdificios1.getText())-Double.parseDouble(txtEdificios2.getText())));
            txtMobiliariodiferencia.setText(""+(Double.parseDouble(txtMobiliario1.getText())-Double.parseDouble(txtMobiliario2.getText())));
            txtEquipoderepartodiferencia.setText(""+(Double.parseDouble(txtEquipodereparto1.getText())-Double.parseDouble(txtEquipodereparto2.getText())));
            txtEquipodetransportediferencia.setText(""+(Double.parseDouble(txtEquipodetransporte1.getText())-Double.parseDouble(txtEquipodetransporte2.getText())));
            txtEquipodecomputodiferencia.setText(""+(Double.parseDouble(txtEquipodecomputo1.getText())-Double.parseDouble(txtEquipodecomputo2.getText())));
            txtGastosdeinstalaciondiferencia.setText(""+(Double.parseDouble(txtGastosdeinstalacion1.getText())-Double.parseDouble(txtGastosdeinstalacion2.getText())));
            txtGastosdeorganizaciondiferencia.setText(""+(Double.parseDouble(txtGastosdeorganizacion1.getText())-Double.parseDouble(txtGastosdeorganizacion2.getText())));
            
            txtProovedoresdiferencia.setText(""+(Double.parseDouble(txtProovedores1.getText())-Double.parseDouble(txtProovedores2.getText())));
            txtAcreedoresdiferencia.setText(""+(Double.parseDouble(txtAcreedores1.getText())-Double.parseDouble(txtAcreedores2.getText())));
            txtDocumentosporpagardiferencia.setText(""+(Double.parseDouble(txtDocumentosporpagar1.getText())-Double.parseDouble(txtDocumentosporpagar2.getText())));
            txtAcreedoreshipotecariosdiferencia.setText(""+(Double.parseDouble(txtAcreedoreshipotecarios1.getText())-Double.parseDouble(txtAcreedoreshipotecarios2.getText())));
            txtDocumentoslargoplazodiferencia.setText(""+(Double.parseDouble(txtDocumentoslargoplazo1.getText())-Double.parseDouble(txtDocumentoslargoplazo2.getText())));
            
            txtCapitalsocialdiferencia.setText(""+(Double.parseDouble(txtCapitalsocial1.getText())-Double.parseDouble(txtCapitalsocial2.getText())));
            txtVentasdiferencia.setText(""+(Double.parseDouble(txtVentas1.getText())-Double.parseDouble(txtVentas2.getText())));
            txtCostodeventasdiferencia.setText(""+(Double.parseDouble(txtCostodeventas1.getText())-Double.parseDouble(txtCostodeventas2.getText())));
            txtGastosdeventasdiferencia.setText(""+(Double.parseDouble(txtGastosdeventas1.getText())-Double.parseDouble(txtGastosdeventas2.getText())));
            txtGastosdeadministraciondiferencia.setText(""+(Double.parseDouble(txtGastosdeadministracion1.getText())-Double.parseDouble(txtGastosdeadministracion2.getText())));
            txtGastosfinancierosdiferencia.setText(""+(Double.parseDouble(txtGastosfinancieros1.getText())-Double.parseDouble(txtGastosfinancieros2.getText())));
            txtOtrosgastosdiferencia.setText(""+(Double.parseDouble(txtOtrosgastos1.getText())-Double.parseDouble(txtOtrosgastos2.getText())));
            txtProductosfinancierosdiferencia.setText(""+(Double.parseDouble(txtProductosfinancieros1.getText())-Double.parseDouble(txtProductosfinancieros2.getText())));
            txtOtrosproductosdiferencia.setText(""+(Double.parseDouble(txtOtrosproductos1.getText())-Double.parseDouble(txtOtrosproductos2.getText())));
            
            txtUtilidadnetadiferencia.setText(""+(Double.parseDouble(txtUtilidadneta1.getText())-Double.parseDouble(txtUtilidadneta2.getText())));
            
            dcaja.addCargo(Double.parseDouble(txtCajadiferencia.getText()));
            dbancos.addCargo(Double.parseDouble(txtBancosdiferencia.getText()));
            dalmacen.addCargo(Double.parseDouble(txtAlmacendiferencia.getText()));
            dclientes.addCargo(Double.parseDouble(txtClientesdiferencia.getText()));
            ddeudores.addCargo(Double.parseDouble(txtDeudoresdiferencia.getText()));
            ddocumentosporcobrar.addCargo(Double.parseDouble(txtDocumentosporcobrardiferencia.getText()));
            dterrenos.addCargo(Double.parseDouble(txtTerrenosdiferencia.getText()));
            dedificios.addCargo(Double.parseDouble(txtEdificiosdiferencia.getText()));
            dmobiliario.addCargo(Double.parseDouble(txtMobiliariodiferencia.getText()));
            dequipodetransporte.addCargo(Double.parseDouble(txtEquipodetransportediferencia.getText()));
            dequipodereparto.addCargo(Double.parseDouble(txtEquipoderepartodiferencia.getText()));
            dequipodecomputo.addCargo(Double.parseDouble(txtEquipodecomputodiferencia.getText()));
            dgastosdeinstalacion.addCargo(Double.parseDouble(txtGastosdeinstalaciondiferencia.getText()));
            dgastosdeorganizacion.addCargo(Double.parseDouble(txtGastosdeorganizaciondiferencia.getText()));
            
            dproovedores.addCargo(Double.parseDouble(txtProovedoresdiferencia.getText()));
            dacreedores.addCargo(Double.parseDouble(txtAcreedoresdiferencia.getText()));
            ddocumentosporpagar.addCargo(Double.parseDouble(txtDocumentosporpagardiferencia.getText()));
            dacreedoreshipotecarios.addCargo(Double.parseDouble(txtAcreedoreshipotecariosdiferencia.getText()));
            ddocumentosporpagarlargoplazo.addCargo(Double.parseDouble(txtDocumentoslargoplazodiferencia.getText()));
            
            dcapitalsocial.addCargo(Double.parseDouble(txtCapitalsocialdiferencia.getText()));
            dutilidadneta.addCargo(Double.parseDouble(txtUtilidadnetadiferencia.getText()));
            
        }
        catch(NumberFormatException e){        }
    }
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel6 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtCaja1 = new javax.swing.JTextField();
        txtCaja2 = new javax.swing.JTextField();
        txtCajadiferencia = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtBancos1 = new javax.swing.JTextField();
        txtBancos2 = new javax.swing.JTextField();
        txtBancosdiferencia = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtAlmacen1 = new javax.swing.JTextField();
        txtAlmacen2 = new javax.swing.JTextField();
        txtAlmacendiferencia = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtClientes1 = new javax.swing.JTextField();
        txtClientes2 = new javax.swing.JTextField();
        txtClientesdiferencia = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtDeudores1 = new javax.swing.JTextField();
        txtDeudores2 = new javax.swing.JTextField();
        txtDeudoresdiferencia = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtDocumentosporcobrar1 = new javax.swing.JTextField();
        txtDocumentosporcobrar2 = new javax.swing.JTextField();
        txtDocumentosporcobrardiferencia = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtActivocirculante1 = new javax.swing.JTextField();
        txtActivocirculante2 = new javax.swing.JTextField();
        txtActivocirculantediferencia = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtTerrenos1 = new javax.swing.JTextField();
        txtTerrenos2 = new javax.swing.JTextField();
        txtTerrenosdiferencia = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtEdificios1 = new javax.swing.JTextField();
        txtEdificios2 = new javax.swing.JTextField();
        txtEdificiosdiferencia = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtMobiliario1 = new javax.swing.JTextField();
        txtMobiliario2 = new javax.swing.JTextField();
        txtMobiliariodiferencia = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtEquipodereparto1 = new javax.swing.JTextField();
        txtEquipodereparto2 = new javax.swing.JTextField();
        txtEquipoderepartodiferencia = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtEquipodetransporte1 = new javax.swing.JTextField();
        txtEquipodetransporte2 = new javax.swing.JTextField();
        txtEquipodetransportediferencia = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtEquipodecomputo1 = new javax.swing.JTextField();
        txtEquipodecomputo2 = new javax.swing.JTextField();
        txtEquipodecomputodiferencia = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        txtActivofijo1 = new javax.swing.JTextField();
        txtActivofijo2 = new javax.swing.JTextField();
        txtActivofijodiferencia = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtGastosdeinstalacion1 = new javax.swing.JTextField();
        txtGastosdeinstalacion2 = new javax.swing.JTextField();
        txtGastosdeinstalaciondiferencia = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtGastosdeorganizacion1 = new javax.swing.JTextField();
        txtGastosdeorganizacion2 = new javax.swing.JTextField();
        txtGastosdeorganizaciondiferencia = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        txtActivodiferido1 = new javax.swing.JTextField();
        txtActivodiferido2 = new javax.swing.JTextField();
        txtActivodiferidodiferencia = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtTotalactivo1 = new javax.swing.JTextField();
        txtTotalactivo2 = new javax.swing.JTextField();
        txtTotalactivodiferencia = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel31 = new javax.swing.JLabel();
        jLabel41 = new javax.swing.JLabel();
        jLabel43 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        txtProovedores1 = new javax.swing.JTextField();
        txtProovedores2 = new javax.swing.JTextField();
        txtProovedoresdiferencia = new javax.swing.JTextField();
        jLabel33 = new javax.swing.JLabel();
        txtAcreedores1 = new javax.swing.JTextField();
        txtAcreedores2 = new javax.swing.JTextField();
        txtAcreedoresdiferencia = new javax.swing.JTextField();
        jLabel34 = new javax.swing.JLabel();
        txtDocumentosporpagar1 = new javax.swing.JTextField();
        txtDocumentosporpagar2 = new javax.swing.JTextField();
        txtDocumentosporpagardiferencia = new javax.swing.JTextField();
        jLabel35 = new javax.swing.JLabel();
        txtPasivocirculante1 = new javax.swing.JTextField();
        txtPasivocirculante2 = new javax.swing.JTextField();
        txtPasivocirculantediferencia = new javax.swing.JTextField();
        jLabel36 = new javax.swing.JLabel();
        jLabel42 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();
        jLabel46 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        txtAcreedoreshipotecarios1 = new javax.swing.JTextField();
        txtAcreedoreshipotecarios2 = new javax.swing.JTextField();
        txtAcreedoreshipotecariosdiferencia = new javax.swing.JTextField();
        jLabel38 = new javax.swing.JLabel();
        txtDocumentoslargoplazo1 = new javax.swing.JTextField();
        txtDocumentoslargoplazo2 = new javax.swing.JTextField();
        txtDocumentoslargoplazodiferencia = new javax.swing.JTextField();
        jLabel39 = new javax.swing.JLabel();
        txtPasivofijo1 = new javax.swing.JTextField();
        txtPasivofijo2 = new javax.swing.JTextField();
        txtPasivofijodiferencia = new javax.swing.JTextField();
        jLabel40 = new javax.swing.JLabel();
        txtTotalpasivo1 = new javax.swing.JTextField();
        txtTotalpasivo2 = new javax.swing.JTextField();
        txtTotalpasivodiferencia = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabel47 = new javax.swing.JLabel();
        txtCapitalsocial1 = new javax.swing.JTextField();
        txtCapitalsocial2 = new javax.swing.JTextField();
        txtCapitalsocialdiferencia = new javax.swing.JTextField();
        jLabel48 = new javax.swing.JLabel();
        txtUtilidadneta1 = new javax.swing.JTextField();
        txtUtilidadneta2 = new javax.swing.JTextField();
        txtUtilidadnetadiferencia = new javax.swing.JTextField();
        jLabel49 = new javax.swing.JLabel();
        txtTotalcapital1 = new javax.swing.JTextField();
        txtTotalcapital2 = new javax.swing.JTextField();
        txtTotalcapitaldiferencia = new javax.swing.JTextField();
        jPanel5 = new javax.swing.JPanel();
        jLabel50 = new javax.swing.JLabel();
        txtVentas1 = new javax.swing.JTextField();
        txtVentas2 = new javax.swing.JTextField();
        txtVentasdiferencia = new javax.swing.JTextField();
        jLabel51 = new javax.swing.JLabel();
        txtCostodeventas1 = new javax.swing.JTextField();
        txtCostodeventas2 = new javax.swing.JTextField();
        txtCostodeventasdiferencia = new javax.swing.JTextField();
        jLabel52 = new javax.swing.JLabel();
        txtGastosdeventas1 = new javax.swing.JTextField();
        txtGastosdeventas2 = new javax.swing.JTextField();
        txtGastosdeventasdiferencia = new javax.swing.JTextField();
        jLabel53 = new javax.swing.JLabel();
        txtGastosdeadministracion1 = new javax.swing.JTextField();
        txtGastosdeadministracion2 = new javax.swing.JTextField();
        txtGastosdeadministraciondiferencia = new javax.swing.JTextField();
        jLabel54 = new javax.swing.JLabel();
        txtGastosfinancieros1 = new javax.swing.JTextField();
        txtGastosfinancieros2 = new javax.swing.JTextField();
        txtGastosfinancierosdiferencia = new javax.swing.JTextField();
        jLabel55 = new javax.swing.JLabel();
        txtOtrosgastos1 = new javax.swing.JTextField();
        txtOtrosgastos2 = new javax.swing.JTextField();
        txtOtrosgastosdiferencia = new javax.swing.JTextField();
        jLabel56 = new javax.swing.JLabel();
        txtProductosfinancieros1 = new javax.swing.JTextField();
        txtProductosfinancieros2 = new javax.swing.JTextField();
        txtProductosfinancierosdiferencia = new javax.swing.JTextField();
        jLabel57 = new javax.swing.JLabel();
        txtOtrosproductos1 = new javax.swing.JTextField();
        txtOtrosproductos2 = new javax.swing.JTextField();
        txtOtrosproductosdiferencia = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();

        jPanel6.setLayout(new java.awt.GridLayout(1, 2));

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Activo"));
        jPanel1.setLayout(new java.awt.GridLayout(21, 4));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel16.setText("CIRCULANTE");
        jPanel1.add(jLabel16);

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel22.setText("2011");
        jPanel1.add(jLabel22);

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel25.setText("2010");
        jPanel1.add(jLabel25);

        jLabel28.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel28.setText("Diferencia");
        jPanel1.add(jLabel28);

        jLabel1.setText("Caja");
        jPanel1.add(jLabel1);

        txtCaja1.setText("jTextField1");
        txtCaja1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCaja1ActionPerformed(evt);
            }
        });
        jPanel1.add(txtCaja1);

        txtCaja2.setText("jTextField19");
        jPanel1.add(txtCaja2);

        txtCajadiferencia.setText("jTextField37");
        txtCajadiferencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCajadiferenciaActionPerformed(evt);
            }
        });
        jPanel1.add(txtCajadiferencia);

        jLabel2.setText("Bancos");
        jPanel1.add(jLabel2);

        txtBancos1.setText("jTextField2");
        jPanel1.add(txtBancos1);

        txtBancos2.setText("jTextField20");
        jPanel1.add(txtBancos2);

        txtBancosdiferencia.setText("jTextField38");
        jPanel1.add(txtBancosdiferencia);

        jLabel3.setText("Almacén");
        jPanel1.add(jLabel3);

        txtAlmacen1.setText("jTextField3");
        jPanel1.add(txtAlmacen1);

        txtAlmacen2.setText("jTextField21");
        jPanel1.add(txtAlmacen2);

        txtAlmacendiferencia.setText("jTextField39");
        jPanel1.add(txtAlmacendiferencia);

        jLabel4.setText("Clientes");
        jPanel1.add(jLabel4);

        txtClientes1.setText("jTextField4");
        jPanel1.add(txtClientes1);

        txtClientes2.setText("jTextField22");
        jPanel1.add(txtClientes2);

        txtClientesdiferencia.setText("jTextField40");
        jPanel1.add(txtClientesdiferencia);

        jLabel5.setText("Deudores");
        jPanel1.add(jLabel5);

        txtDeudores1.setText("jTextField5");
        jPanel1.add(txtDeudores1);

        txtDeudores2.setText("jTextField23");
        jPanel1.add(txtDeudores2);

        txtDeudoresdiferencia.setText("jTextField41");
        jPanel1.add(txtDeudoresdiferencia);

        jLabel6.setText("Documentos por cobrar");
        jPanel1.add(jLabel6);

        txtDocumentosporcobrar1.setText("jTextField6");
        jPanel1.add(txtDocumentosporcobrar1);

        txtDocumentosporcobrar2.setText("jTextField24");
        jPanel1.add(txtDocumentosporcobrar2);

        txtDocumentosporcobrardiferencia.setText("jTextField42");
        jPanel1.add(txtDocumentosporcobrardiferencia);

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel17.setText("Total de circulante");
        jPanel1.add(jLabel17);

        txtActivocirculante1.setText("jTextField25");
        jPanel1.add(txtActivocirculante1);

        txtActivocirculante2.setText("jTextField26");
        jPanel1.add(txtActivocirculante2);

        txtActivocirculantediferencia.setText("jTextField43");
        jPanel1.add(txtActivocirculantediferencia);

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel18.setText("FIJO");
        jPanel1.add(jLabel18);
        jPanel1.add(jLabel23);
        jPanel1.add(jLabel26);
        jPanel1.add(jLabel29);

        jLabel7.setText("Terrenos");
        jPanel1.add(jLabel7);

        txtTerrenos1.setText("jTextField8");
        jPanel1.add(txtTerrenos1);

        txtTerrenos2.setText("jTextField7");
        jPanel1.add(txtTerrenos2);

        txtTerrenosdiferencia.setText("jTextField44");
        jPanel1.add(txtTerrenosdiferencia);

        jLabel8.setText("Edificios");
        jPanel1.add(jLabel8);

        txtEdificios1.setText("jTextField9");
        jPanel1.add(txtEdificios1);

        txtEdificios2.setText("jTextField27");
        jPanel1.add(txtEdificios2);

        txtEdificiosdiferencia.setText("jTextField45");
        jPanel1.add(txtEdificiosdiferencia);

        jLabel9.setText("Mobiliario");
        jPanel1.add(jLabel9);

        txtMobiliario1.setText("jTextField10");
        jPanel1.add(txtMobiliario1);

        txtMobiliario2.setText("jTextField28");
        jPanel1.add(txtMobiliario2);

        txtMobiliariodiferencia.setText("jTextField51");
        jPanel1.add(txtMobiliariodiferencia);

        jLabel10.setText("Equipo de reparto");
        jPanel1.add(jLabel10);

        txtEquipodereparto1.setText("jTextField11");
        jPanel1.add(txtEquipodereparto1);

        txtEquipodereparto2.setText("jTextField29");
        jPanel1.add(txtEquipodereparto2);

        txtEquipoderepartodiferencia.setText("jTextField13");
        jPanel1.add(txtEquipoderepartodiferencia);

        jLabel11.setText("Equipo de transporte");
        jPanel1.add(jLabel11);

        txtEquipodetransporte1.setText("jTextField12");
        jPanel1.add(txtEquipodetransporte1);

        txtEquipodetransporte2.setText("jTextField30");
        jPanel1.add(txtEquipodetransporte2);

        txtEquipodetransportediferencia.setText("jTextField32");
        jPanel1.add(txtEquipodetransportediferencia);

        jLabel12.setText("Equipo de cómputo");
        jPanel1.add(jLabel12);

        txtEquipodecomputo1.setText("jTextField31");
        jPanel1.add(txtEquipodecomputo1);

        txtEquipodecomputo2.setText("jTextField14");
        jPanel1.add(txtEquipodecomputo2);

        txtEquipodecomputodiferencia.setText("jTextField33");
        jPanel1.add(txtEquipodecomputodiferencia);

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel19.setText("Total de fijo");
        jPanel1.add(jLabel19);

        txtActivofijo1.setText("jTextField46");
        jPanel1.add(txtActivofijo1);

        txtActivofijo2.setText("jTextField15");
        jPanel1.add(txtActivofijo2);

        txtActivofijodiferencia.setText("jTextField34");
        jPanel1.add(txtActivofijodiferencia);

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel20.setText("DIFERIDO");
        jPanel1.add(jLabel20);
        jPanel1.add(jLabel24);
        jPanel1.add(jLabel27);
        jPanel1.add(jLabel30);

        jLabel13.setText("Gastos de instalación");
        jPanel1.add(jLabel13);

        txtGastosdeinstalacion1.setText("jTextField47");
        jPanel1.add(txtGastosdeinstalacion1);

        txtGastosdeinstalacion2.setText("jTextField16");
        txtGastosdeinstalacion2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtGastosdeinstalacion2ActionPerformed(evt);
            }
        });
        jPanel1.add(txtGastosdeinstalacion2);

        txtGastosdeinstalaciondiferencia.setText("jTextField35");
        jPanel1.add(txtGastosdeinstalaciondiferencia);

        jLabel14.setText("Gastos de organización");
        jPanel1.add(jLabel14);

        txtGastosdeorganizacion1.setText("jTextField48");
        jPanel1.add(txtGastosdeorganizacion1);

        txtGastosdeorganizacion2.setText("jTextField17");
        jPanel1.add(txtGastosdeorganizacion2);

        txtGastosdeorganizaciondiferencia.setText("jTextField36");
        jPanel1.add(txtGastosdeorganizaciondiferencia);

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel21.setText("Total de diferido");
        jPanel1.add(jLabel21);

        txtActivodiferido1.setText("jTextField49");
        jPanel1.add(txtActivodiferido1);

        txtActivodiferido2.setText("jTextField18");
        jPanel1.add(txtActivodiferido2);

        txtActivodiferidodiferencia.setText("jTextField50");
        jPanel1.add(txtActivodiferidodiferencia);

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("Total de activo");
        jPanel1.add(jLabel15);

        txtTotalactivo1.setText("txtTotalactivo1");
        txtTotalactivo1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalactivo1ActionPerformed(evt);
            }
        });
        jPanel1.add(txtTotalactivo1);

        txtTotalactivo2.setText("jTextField2");
        jPanel1.add(txtTotalactivo2);

        txtTotalactivodiferencia.setText("jTextField3");
        jPanel1.add(txtTotalactivodiferencia);

        jPanel6.add(jPanel1);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Pasivo"));
        jPanel3.setLayout(new java.awt.GridLayout(10, 4));

        jLabel31.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel31.setText("CIRCULANTE");
        jPanel3.add(jLabel31);

        jLabel41.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel41.setText("2011");
        jPanel3.add(jLabel41);

        jLabel43.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel43.setText("2010");
        jPanel3.add(jLabel43);

        jLabel45.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel45.setText("Diferencia");
        jPanel3.add(jLabel45);

        jLabel32.setText("Proovedores");
        jPanel3.add(jLabel32);

        txtProovedores1.setText("jTextField52");
        jPanel3.add(txtProovedores1);

        txtProovedores2.setText("jTextField60");
        jPanel3.add(txtProovedores2);

        txtProovedoresdiferencia.setText("jTextField68");
        jPanel3.add(txtProovedoresdiferencia);

        jLabel33.setText("Acreedores");
        jPanel3.add(jLabel33);

        txtAcreedores1.setText("jTextField53");
        jPanel3.add(txtAcreedores1);

        txtAcreedores2.setText("jTextField61");
        jPanel3.add(txtAcreedores2);

        txtAcreedoresdiferencia.setText("jTextField69");
        jPanel3.add(txtAcreedoresdiferencia);

        jLabel34.setText("Documentos por pagar");
        jPanel3.add(jLabel34);

        txtDocumentosporpagar1.setText("jTextField54");
        jPanel3.add(txtDocumentosporpagar1);

        txtDocumentosporpagar2.setText("jTextField62");
        jPanel3.add(txtDocumentosporpagar2);

        txtDocumentosporpagardiferencia.setText("jTextField70");
        jPanel3.add(txtDocumentosporpagardiferencia);

        jLabel35.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel35.setText("Total de circulante");
        jPanel3.add(jLabel35);

        txtPasivocirculante1.setText("jTextField55");
        jPanel3.add(txtPasivocirculante1);

        txtPasivocirculante2.setText("jTextField63");
        jPanel3.add(txtPasivocirculante2);

        txtPasivocirculantediferencia.setText("jTextField71");
        jPanel3.add(txtPasivocirculantediferencia);

        jLabel36.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel36.setText("FIJO");
        jPanel3.add(jLabel36);
        jPanel3.add(jLabel42);
        jPanel3.add(jLabel44);
        jPanel3.add(jLabel46);

        jLabel37.setText("Acreedores hipotecarios");
        jPanel3.add(jLabel37);

        txtAcreedoreshipotecarios1.setText("jTextField56");
        jPanel3.add(txtAcreedoreshipotecarios1);

        txtAcreedoreshipotecarios2.setText("jTextField64");
        jPanel3.add(txtAcreedoreshipotecarios2);

        txtAcreedoreshipotecariosdiferencia.setText("jTextField72");
        jPanel3.add(txtAcreedoreshipotecariosdiferencia);

        jLabel38.setText("Documentos largo plazo");
        jPanel3.add(jLabel38);

        txtDocumentoslargoplazo1.setText("jTextField57");
        jPanel3.add(txtDocumentoslargoplazo1);

        txtDocumentoslargoplazo2.setText("jTextField65");
        jPanel3.add(txtDocumentoslargoplazo2);

        txtDocumentoslargoplazodiferencia.setText("jTextField73");
        jPanel3.add(txtDocumentoslargoplazodiferencia);

        jLabel39.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel39.setText("Total de fijo");
        jPanel3.add(jLabel39);

        txtPasivofijo1.setText("jTextField58");
        jPanel3.add(txtPasivofijo1);

        txtPasivofijo2.setText("jTextField66");
        jPanel3.add(txtPasivofijo2);

        txtPasivofijodiferencia.setText("jTextField74");
        jPanel3.add(txtPasivofijodiferencia);

        jLabel40.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel40.setText("Total de pasivo");
        jPanel3.add(jLabel40);

        txtTotalpasivo1.setText("jTextField59");
        jPanel3.add(txtTotalpasivo1);

        txtTotalpasivo2.setText("jTextField67");
        jPanel3.add(txtTotalpasivo2);

        txtTotalpasivodiferencia.setText("jTextField75");
        jPanel3.add(txtTotalpasivodiferencia);

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 280));

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Capital"));
        jPanel4.setLayout(new java.awt.GridLayout(3, 4));

        jLabel47.setText("Capital social");
        jPanel4.add(jLabel47);

        txtCapitalsocial1.setText("jTextField76");
        jPanel4.add(txtCapitalsocial1);

        txtCapitalsocial2.setText("jTextField79");
        jPanel4.add(txtCapitalsocial2);

        txtCapitalsocialdiferencia.setText("jTextField104");
        jPanel4.add(txtCapitalsocialdiferencia);

        jLabel48.setText("Utilidad neta");
        jPanel4.add(jLabel48);

        txtUtilidadneta1.setText("jTextField77");
        jPanel4.add(txtUtilidadneta1);

        txtUtilidadneta2.setText("jTextField80");
        jPanel4.add(txtUtilidadneta2);

        txtUtilidadnetadiferencia.setText("jTextField105");
        jPanel4.add(txtUtilidadnetadiferencia);

        jLabel49.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel49.setText("Total de capital");
        jPanel4.add(jLabel49);

        txtTotalcapital1.setText("jTextField78");
        jPanel4.add(txtTotalcapital1);

        txtTotalcapital2.setText("jTextField81");
        jPanel4.add(txtTotalcapital2);

        txtTotalcapitaldiferencia.setText("jTextField106");
        jPanel4.add(txtTotalcapitaldiferencia);

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 284, 476, 100));

        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Ventas"));
        jPanel5.setLayout(new java.awt.GridLayout(8, 4));

        jLabel50.setText("Ventas");
        jPanel5.add(jLabel50);

        txtVentas1.setText("jTextField82");
        jPanel5.add(txtVentas1);

        txtVentas2.setText("jTextField93");
        jPanel5.add(txtVentas2);

        txtVentasdiferencia.setText("jTextField107");
        jPanel5.add(txtVentasdiferencia);

        jLabel51.setText("Costo de ventas");
        jPanel5.add(jLabel51);

        txtCostodeventas1.setText("jTextField83");
        jPanel5.add(txtCostodeventas1);

        txtCostodeventas2.setText("jTextField94");
        jPanel5.add(txtCostodeventas2);

        txtCostodeventasdiferencia.setText("jTextField108");
        jPanel5.add(txtCostodeventasdiferencia);

        jLabel52.setText("Gastos de ventas");
        jPanel5.add(jLabel52);

        txtGastosdeventas1.setText("jTextField84");
        jPanel5.add(txtGastosdeventas1);

        txtGastosdeventas2.setText("jTextField95");
        jPanel5.add(txtGastosdeventas2);

        txtGastosdeventasdiferencia.setText("jTextField109");
        jPanel5.add(txtGastosdeventasdiferencia);

        jLabel53.setText("Gastos de administracion");
        jPanel5.add(jLabel53);

        txtGastosdeadministracion1.setText("jTextField85");
        jPanel5.add(txtGastosdeadministracion1);

        txtGastosdeadministracion2.setText("jTextField96");
        jPanel5.add(txtGastosdeadministracion2);

        txtGastosdeadministraciondiferencia.setText("jTextField110");
        jPanel5.add(txtGastosdeadministraciondiferencia);

        jLabel54.setText("Gastos financieros");
        jPanel5.add(jLabel54);

        txtGastosfinancieros1.setText("jTextField86");
        jPanel5.add(txtGastosfinancieros1);

        txtGastosfinancieros2.setText("jTextField97");
        jPanel5.add(txtGastosfinancieros2);

        txtGastosfinancierosdiferencia.setText("jTextField111");
        jPanel5.add(txtGastosfinancierosdiferencia);

        jLabel55.setText("Otros gastos");
        jPanel5.add(jLabel55);

        txtOtrosgastos1.setText("jTextField87");
        jPanel5.add(txtOtrosgastos1);

        txtOtrosgastos2.setText("jTextField98");
        jPanel5.add(txtOtrosgastos2);

        txtOtrosgastosdiferencia.setText("jTextField112");
        jPanel5.add(txtOtrosgastosdiferencia);

        jLabel56.setText("Productos financieros");
        jPanel5.add(jLabel56);

        txtProductosfinancieros1.setText("jTextField88");
        jPanel5.add(txtProductosfinancieros1);

        txtProductosfinancieros2.setText("jTextField99");
        jPanel5.add(txtProductosfinancieros2);

        txtProductosfinancierosdiferencia.setText("jTextField113");
        jPanel5.add(txtProductosfinancierosdiferencia);

        jLabel57.setText("Otros productos");
        jPanel5.add(jLabel57);

        txtOtrosproductos1.setText("jTextField89");
        jPanel5.add(txtOtrosproductos1);

        txtOtrosproductos2.setText("jTextField100");
        jPanel5.add(txtOtrosproductos2);

        txtOtrosproductosdiferencia.setText("jTextField114");
        jPanel5.add(txtOtrosproductosdiferencia);

        jPanel2.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 386, 476, 270));

        jPanel6.add(jPanel2);

        getContentPane().add(jPanel6, java.awt.BorderLayout.CENTER);

        jButton1.setText("Regresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel7.add(jButton1);

        getContentPane().add(jPanel7, java.awt.BorderLayout.SOUTH);
    }// </editor-fold>//GEN-END:initComponents

    private void txtGastosdeinstalacion2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtGastosdeinstalacion2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtGastosdeinstalacion2ActionPerformed

    private void txtCaja1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCaja1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCaja1ActionPerformed

    private void txtTotalactivo1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalactivo1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalactivo1ActionPerformed

    private void txtCajadiferenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCajadiferenciaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCajadiferenciaActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel42;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel46;
    private javax.swing.JLabel jLabel47;
    private javax.swing.JLabel jLabel48;
    private javax.swing.JLabel jLabel49;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel50;
    private javax.swing.JLabel jLabel51;
    private javax.swing.JLabel jLabel52;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel54;
    private javax.swing.JLabel jLabel55;
    private javax.swing.JLabel jLabel56;
    private javax.swing.JLabel jLabel57;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JTextField txtAcreedores1;
    private javax.swing.JTextField txtAcreedores2;
    private javax.swing.JTextField txtAcreedoresdiferencia;
    private javax.swing.JTextField txtAcreedoreshipotecarios1;
    private javax.swing.JTextField txtAcreedoreshipotecarios2;
    private javax.swing.JTextField txtAcreedoreshipotecariosdiferencia;
    private javax.swing.JTextField txtActivocirculante1;
    private javax.swing.JTextField txtActivocirculante2;
    private javax.swing.JTextField txtActivocirculantediferencia;
    private javax.swing.JTextField txtActivodiferido1;
    private javax.swing.JTextField txtActivodiferido2;
    private javax.swing.JTextField txtActivodiferidodiferencia;
    private javax.swing.JTextField txtActivofijo1;
    private javax.swing.JTextField txtActivofijo2;
    private javax.swing.JTextField txtActivofijodiferencia;
    private javax.swing.JTextField txtAlmacen1;
    private javax.swing.JTextField txtAlmacen2;
    private javax.swing.JTextField txtAlmacendiferencia;
    private javax.swing.JTextField txtBancos1;
    private javax.swing.JTextField txtBancos2;
    private javax.swing.JTextField txtBancosdiferencia;
    private javax.swing.JTextField txtCaja1;
    private javax.swing.JTextField txtCaja2;
    private javax.swing.JTextField txtCajadiferencia;
    private javax.swing.JTextField txtCapitalsocial1;
    private javax.swing.JTextField txtCapitalsocial2;
    private javax.swing.JTextField txtCapitalsocialdiferencia;
    private javax.swing.JTextField txtClientes1;
    private javax.swing.JTextField txtClientes2;
    private javax.swing.JTextField txtClientesdiferencia;
    private javax.swing.JTextField txtCostodeventas1;
    private javax.swing.JTextField txtCostodeventas2;
    private javax.swing.JTextField txtCostodeventasdiferencia;
    private javax.swing.JTextField txtDeudores1;
    private javax.swing.JTextField txtDeudores2;
    private javax.swing.JTextField txtDeudoresdiferencia;
    private javax.swing.JTextField txtDocumentoslargoplazo1;
    private javax.swing.JTextField txtDocumentoslargoplazo2;
    private javax.swing.JTextField txtDocumentoslargoplazodiferencia;
    private javax.swing.JTextField txtDocumentosporcobrar1;
    private javax.swing.JTextField txtDocumentosporcobrar2;
    private javax.swing.JTextField txtDocumentosporcobrardiferencia;
    private javax.swing.JTextField txtDocumentosporpagar1;
    private javax.swing.JTextField txtDocumentosporpagar2;
    private javax.swing.JTextField txtDocumentosporpagardiferencia;
    private javax.swing.JTextField txtEdificios1;
    private javax.swing.JTextField txtEdificios2;
    private javax.swing.JTextField txtEdificiosdiferencia;
    private javax.swing.JTextField txtEquipodecomputo1;
    private javax.swing.JTextField txtEquipodecomputo2;
    private javax.swing.JTextField txtEquipodecomputodiferencia;
    private javax.swing.JTextField txtEquipodereparto1;
    private javax.swing.JTextField txtEquipodereparto2;
    private javax.swing.JTextField txtEquipoderepartodiferencia;
    private javax.swing.JTextField txtEquipodetransporte1;
    private javax.swing.JTextField txtEquipodetransporte2;
    private javax.swing.JTextField txtEquipodetransportediferencia;
    private javax.swing.JTextField txtGastosdeadministracion1;
    private javax.swing.JTextField txtGastosdeadministracion2;
    private javax.swing.JTextField txtGastosdeadministraciondiferencia;
    private javax.swing.JTextField txtGastosdeinstalacion1;
    private javax.swing.JTextField txtGastosdeinstalacion2;
    private javax.swing.JTextField txtGastosdeinstalaciondiferencia;
    private javax.swing.JTextField txtGastosdeorganizacion1;
    private javax.swing.JTextField txtGastosdeorganizacion2;
    private javax.swing.JTextField txtGastosdeorganizaciondiferencia;
    private javax.swing.JTextField txtGastosdeventas1;
    private javax.swing.JTextField txtGastosdeventas2;
    private javax.swing.JTextField txtGastosdeventasdiferencia;
    private javax.swing.JTextField txtGastosfinancieros1;
    private javax.swing.JTextField txtGastosfinancieros2;
    private javax.swing.JTextField txtGastosfinancierosdiferencia;
    private javax.swing.JTextField txtMobiliario1;
    private javax.swing.JTextField txtMobiliario2;
    private javax.swing.JTextField txtMobiliariodiferencia;
    private javax.swing.JTextField txtOtrosgastos1;
    private javax.swing.JTextField txtOtrosgastos2;
    private javax.swing.JTextField txtOtrosgastosdiferencia;
    private javax.swing.JTextField txtOtrosproductos1;
    private javax.swing.JTextField txtOtrosproductos2;
    private javax.swing.JTextField txtOtrosproductosdiferencia;
    private javax.swing.JTextField txtPasivocirculante1;
    private javax.swing.JTextField txtPasivocirculante2;
    private javax.swing.JTextField txtPasivocirculantediferencia;
    private javax.swing.JTextField txtPasivofijo1;
    private javax.swing.JTextField txtPasivofijo2;
    private javax.swing.JTextField txtPasivofijodiferencia;
    private javax.swing.JTextField txtProductosfinancieros1;
    private javax.swing.JTextField txtProductosfinancieros2;
    private javax.swing.JTextField txtProductosfinancierosdiferencia;
    private javax.swing.JTextField txtProovedores1;
    private javax.swing.JTextField txtProovedores2;
    private javax.swing.JTextField txtProovedoresdiferencia;
    private javax.swing.JTextField txtTerrenos1;
    private javax.swing.JTextField txtTerrenos2;
    private javax.swing.JTextField txtTerrenosdiferencia;
    private javax.swing.JTextField txtTotalactivo1;
    private javax.swing.JTextField txtTotalactivo2;
    private javax.swing.JTextField txtTotalactivodiferencia;
    private javax.swing.JTextField txtTotalcapital1;
    private javax.swing.JTextField txtTotalcapital2;
    private javax.swing.JTextField txtTotalcapitaldiferencia;
    private javax.swing.JTextField txtTotalpasivo1;
    private javax.swing.JTextField txtTotalpasivo2;
    private javax.swing.JTextField txtTotalpasivodiferencia;
    private javax.swing.JTextField txtUtilidadneta1;
    private javax.swing.JTextField txtUtilidadneta2;
    private javax.swing.JTextField txtUtilidadnetadiferencia;
    private javax.swing.JTextField txtVentas1;
    private javax.swing.JTextField txtVentas2;
    private javax.swing.JTextField txtVentasdiferencia;
    // End of variables declaration//GEN-END:variables

 
}
