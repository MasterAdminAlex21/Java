/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinanzas.beans;

import proyectofinanzas.beans.CuentasPredefinidas;
import java.util.ArrayList;


/**
 *
 * @author plata
 */
public class Reporte {

    private Integer anio;
    private final ArrayList<Cuenta> activos = new ArrayList<Cuenta>();
    private final ArrayList<Cuenta> pasivos = new ArrayList<Cuenta>();
    private final ArrayList<Cuenta> capital = new ArrayList<Cuenta>();
    private final ArrayList<Cuenta> ocultas = new ArrayList<Cuenta>();
    private final ArrayList<Cuenta> diferencias = new ArrayList<Cuenta>();    

    public Reporte(Integer anio) {
        this.anio = anio;
        CuentasPredefinidas.anadirActivos(this);
        CuentasPredefinidas.anadirPasivos(this);
        CuentasPredefinidas.anadirOtros(this);
        CuentasPredefinidas.anadirOcultas(this);
        CuentasPredefinidas.anadirDiferencias(this);
    } 
    
    public void addActivo(Cuenta cuenta) {
        this.activos.add(cuenta);
    }

    public void addPasivo(Cuenta cuenta) {
        this.pasivos.add(cuenta);
    }

    public void addOtros(Cuenta cuenta) {
        this.capital.add(cuenta);
    }
    
    public void addOcultas (Cuenta cuenta){
        this.ocultas.add(cuenta);
    }
    
    public void addDiferencias (Cuenta cuenta){
        this.diferencias.add(cuenta);
    }
   

    public ArrayList<Cuenta> getActivos() {
        return activos;
    }

    public ArrayList<Cuenta> getOtros() {
        return capital;
    }

    public ArrayList<Cuenta> getPasivos() {
        return pasivos;
    }
    
    public ArrayList<Cuenta> getOcultas() {
        return ocultas;
    }
    
    public ArrayList<Cuenta> getDiferencias() {
        return diferencias;
    }

    public Integer getAnio() {
        return anio;
    }

    @Override
    public String toString() {
        return anio.toString();
    }


    public Double getTotalActivos(){
        double sum = 0;
        for (Cuenta cuenta : activos) {
            sum += cuenta.getTotal();
        }
        return sum;
    }
    
    public Double getTotalPasivos(){
        double sum = 0;
        for (Cuenta cuenta : pasivos) {
            sum += cuenta.getTotal(true);
        }
        return sum;
    }
    public Double getTotalOtros(){
        double sum = 0;
        Cuenta c = GetCuentaName.getCuentaName(capital, "Ventas");
        //for (Cuenta cuenta : pasivos) {
            sum += c.getTotal(true);
        //}
        return sum;
    }
    
    public Double getTotalDiferencias(){
        double sum = 0;
        for (Cuenta cuenta : diferencias) {
            sum += cuenta.getTotal(true);
        }
        return sum;
    }
    
}
