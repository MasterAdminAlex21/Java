/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinanzas.beans;

/**
 *
 * @author plata
 */
class CuentasPredefinidas {

    public static void anadirActivos(Reporte rep) {
        rep.addActivo(new Cuenta("Caja"));
        rep.addActivo(new Cuenta("Bancos"));
        rep.addActivo(new Cuenta("Almacen"));
        rep.addActivo(new Cuenta("Clientes"));
        rep.addActivo(new Cuenta("Deudores"));
        rep.addActivo(new Cuenta("Documentos por cobrar"));
        rep.addActivo(new Cuenta("Terrenos"));
        rep.addActivo(new Cuenta("Edificios"));
        rep.addActivo(new Cuenta("Mobiliario"));
        rep.addActivo(new Cuenta("Equipo de reparto"));
        rep.addActivo(new Cuenta("Equipo de transporte"));
        rep.addActivo(new Cuenta("Equipo de computo"));
        rep.addActivo(new Cuenta("Gastos de instalacion"));
        rep.addActivo(new Cuenta("Gastos de organizacion"));
    }

    public static void anadirPasivos(Reporte rep) {
        rep.addPasivo(new Cuenta("Proovedores"));
        rep.addPasivo(new Cuenta("Acreedores"));
        rep.addPasivo(new Cuenta("Documentos por pagar"));
        rep.addPasivo(new Cuenta("Acreedores hipotecarios"));
        rep.addPasivo(new Cuenta("Documentos por pagar largo plazo"));
    }

    public static void anadirOtros(Reporte rep) {
        rep.addOtros(new Cuenta("Capital social"));
        rep.addOtros(new Cuenta("Ventas"));
        rep.addOtros(new Cuenta("Costo de ventas"));
        rep.addOtros(new Cuenta("Gastos de ventas"));
        rep.addOtros(new Cuenta("Gastos de administracion"));
        rep.addOtros(new Cuenta("Gastos financieros"));
        rep.addOtros(new Cuenta("Otros gastos"));
        rep.addOtros(new Cuenta("Productos financieros"));
        rep.addOtros(new Cuenta("Otros productos"));
    }
    
    public static void anadirOcultas(Reporte rep){
        rep.addOcultas(new Cuenta("Utilidad neta"));
        rep.addOcultas(new Cuenta("Utilidad bruta"));
        rep.addOcultas(new Cuenta("Utilidad antes de impuestos"));
        rep.addOcultas(new Cuenta("Activo circulante"));
        rep.addOcultas(new Cuenta("Activo fijo"));
        rep.addOcultas(new Cuenta("Activo diferido"));
        rep.addOcultas(new Cuenta("Pasivo circulante"));
        rep.addOcultas(new Cuenta("Pasivo fijo"));
        rep.addOcultas(new Cuenta("Pasivo diferido"));
    }
    
    public static void anadirDiferencias(Reporte rep){
        rep.addDiferencias(new Cuenta("DCaja"));
        rep.addDiferencias(new Cuenta("DBancos"));
        rep.addDiferencias(new Cuenta("DAlmacen"));
        rep.addDiferencias(new Cuenta("DClientes"));
        rep.addDiferencias(new Cuenta("DDeudores"));
        rep.addDiferencias(new Cuenta("DDocumentos por cobrar"));
        rep.addDiferencias(new Cuenta("DTerrenos"));
        rep.addDiferencias(new Cuenta("DEdificios"));
        rep.addDiferencias(new Cuenta("DMobiliario"));
        rep.addDiferencias(new Cuenta("DEquipo de reparto"));
        rep.addDiferencias(new Cuenta("DEquipo de transporte"));
        rep.addDiferencias(new Cuenta("DEquipo de computo"));
        rep.addDiferencias(new Cuenta("DGastos de instalacion"));
        rep.addDiferencias(new Cuenta("DGastos de organizacion"));
  
        rep.addDiferencias(new Cuenta("DProovedores"));
        rep.addDiferencias(new Cuenta("DAcreedores"));
        rep.addDiferencias(new Cuenta("DDocumentos por pagar"));
        rep.addDiferencias(new Cuenta("DAcreedores hipotecarios"));
        rep.addDiferencias(new Cuenta("DDocumentos por pagar largo plazo"));
        
        rep.addDiferencias(new Cuenta("DCapital social"));
        rep.addDiferencias(new Cuenta("DUtilidad neta"));
    }
    

    
}
