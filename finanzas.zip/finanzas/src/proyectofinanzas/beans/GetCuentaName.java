/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinanzas.beans;

import java.util.ArrayList;

/**
 *
 * @author Plata
 */
public class GetCuentaName {
    
    
    public static Cuenta getCuentaName(ArrayList<Cuenta> list, String name){
        Cuenta cu = null;
        for (Cuenta cuenta : list) {
            if(cuenta.getNombre().equals(name)){
                cu = cuenta;
                break;
            }
        }
        return cu;
    }
    
}
