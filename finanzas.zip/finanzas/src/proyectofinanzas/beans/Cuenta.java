/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinanzas.beans;

import java.util.ArrayList;

/**
 *
 * @author plata
 */
public class Cuenta {
    private String nombre = "";
    private final ArrayList<Double> cargo = new ArrayList<Double>();
    private final ArrayList<Double> abono = new ArrayList<Double>();

    public Cuenta() {}

    public Cuenta(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public void addCargo(Double cargo){
        this.cargo.add(cargo);
    }
    
    public void addAbono(Double abono){
        this.abono.add(abono);
    }
    
    
    public double getTotalCargo(){       
        double suma = 0;
        for (Double ca : cargo)  suma += ca;
        return suma;
    }
    
    public double getTotalAbono(){       
        double suma = 0;
        for (Double ab : abono) suma += ab;      
        return suma;
    }

    public ArrayList<Double> getAbono() {
        return abono;
    }

    public ArrayList<Double> getCargo() {
        return cargo;
    }

    @Override
    public String toString() {
        return nombre;
    }

    /**
     * 
     * @param inverso TRUE: (abono - cargo) FALSE: (cargo - abono)
     * @return 
     */
    public Double getTotal(boolean inverso){
        if(inverso){
            return getTotalAbono()-getTotalCargo();
        } else {
            return getTotalCargo()-getTotalAbono();
        }
    }
    /**
     * Metodo getTotal(false);
     * @see Cuenta#getTotal(boolean);
     * @return 
     */
    public Double getTotal(){
        return getTotal(false);
    }
    
    
}
