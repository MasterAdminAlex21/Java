/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinanzas;

/**
 *
 * @author Plata
 */
import proyectofinanzas.beans.Cuenta;
import proyectofinanzas.beans.Reporte;
import proyectofinanzas.beans.GetCuentaName;
import java.text.*;

public class BalanceGeneral extends javax.swing.JFrame {
    
    /**
     * Creates new form BalanceGeneral
     */
    public BalanceGeneral(Reporte rep) {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Balance General");
        initComponents();
        setReporte(rep);
    }

    
    private Reporte rep;
    
    
    public final void setReporte(Reporte rep){
        this.rep = rep;
        DecimalFormat df = new DecimalFormat("##.##");
        
        double totalActivos = rep.getTotalActivos();
        double totalP = rep.getTotalPasivos();
        double totalO = rep.getTotalOtros();
        txtTotalActivo.setText("$"+totalActivos);
        
        
        { // Caja
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Caja");
            double totalC = c.getTotal();
            double cajaP = ((totalC*100)/totalActivos);
            txtCaja.setText("$"+totalC);
            lblCaja.setText(""+df.format(cajaP)+"%");
        }
        { // Bancos
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Bancos");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtBancos.setText("$"+totalC);
            lblBancos.setText(df.format(cajaP)+"%");
        }
        { //Almacen
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Caja");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtAlmacen.setText("$"+totalC);
            lblAlmacen.setText(df.format(cajaP)+"%");
        }
        
        { // Clientes
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Clientes");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtClientes.setText("$"+totalC);
            lblClientes.setText(df.format(cajaP)+"%");
        }
        
        { // Deudores
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Deudores");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtDeudores.setText("$"+totalC);
            lblDeudores.setText(df.format(cajaP)+"%");
        }
        { // Documentos por cobrar
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Documentos por cobrar");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtDocumentosporCobrar.setText("$"+totalC);
            lblDocumentosporcobrar.setText(df.format(cajaP)+"%");
        }
        { // Terrenos
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Terrenos");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtTerrenos.setText("$"+totalC);
            lblTerrenos.setText(df.format(cajaP)+"%");
        }
        { // Edificios
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Edificios");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEdificios.setText("$"+totalC);
            lblEdificios.setText(df.format(cajaP)+"%");
        }
        { // Mobiliairo
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Mobiliario");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtMobiliario.setText("$"+totalC);
            lblMobiliario.setText(df.format(cajaP)+"%");
        }
        { // Equipo de reparto
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Equipo de reparto");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEquipodeReparto.setText("$"+totalC);
            lblEquipodeReparto.setText(df.format(cajaP)+"%");
        }
        { // Equipo de transporte
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Equipo de transporte");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEquipodeTransporte.setText("$"+totalC);
            lblEquipodeTransporte.setText(df.format(cajaP)+"%");
        }
        { // Equipo de computo
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Equipo de computo");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtEquipodeComputo.setText("$"+totalC);
            lblEquipodeComputo.setText(df.format(cajaP)+"%");
        }
        { // Gastos de instalacion
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Gastos de instalacion");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtGastosdeInstalacion.setText("$"+totalC);
            lblGastosdeInstalacion.setText(df.format(cajaP)+"%");
        }
        { // Gastos de organizacion
            Cuenta c = GetCuentaName.getCuentaName(rep.getActivos(), "Gastos de organizacion");
            double totalC = c.getTotal();
            double cajaP = (totalC*100)/totalActivos;
            txtGastosdeOrganizacion.setText("$"+totalC);
            lblGastosdeOrganizacion.setText(df.format(cajaP)+"%");
        }
        
        { // Proovedores
            Cuenta c = GetCuentaName.getCuentaName(rep.getPasivos(), "Proovedores");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtProovedores.setText("$"+totalC);
            lblProovedores.setText(df.format(cajaP)+"%");
        }
        { // Acreedores
            Cuenta c = GetCuentaName.getCuentaName(rep.getPasivos(), "Acreedores");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtAcreedores.setText("$"+totalC);
            lblAcreedores.setText(df.format(cajaP)+"%");
        }
        { // Documentos por pagar
            Cuenta c = GetCuentaName.getCuentaName(rep.getPasivos(), "Documentos por pagar");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtDocumentosporPagar.setText("$"+totalC);
            lblDocumentosporPagar.setText(df.format(cajaP)+"%");
        }
        { // Acreedores hipotecarios
            Cuenta c = GetCuentaName.getCuentaName(rep.getPasivos(), "Acreedores hipotecarios");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtAcreedoresHipotecarios.setText("$"+totalC);
            lblAcreedoresHipotecarios.setText(df.format(cajaP)+"%");
        }
        { // Documentos por pagar largo plazo
            Cuenta c = GetCuentaName.getCuentaName(rep.getPasivos(), "Documentos por pagar largo plazo");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalP;
            txtDocumentosLargoPlazo.setText("$"+totalC);
            lblDocumentosLargoPlazo.setText(df.format(cajaP)+"%");
        }
        { // Capital Social
            Cuenta c = GetCuentaName.getCuentaName(rep.getOtros(), "Capital social");
            double totalC = c.getTotal(true);
            double cajaP = (totalC*100)/totalO;
            txtCapitalSocal.setText("$"+totalC);
            lblCapitalSocial.setText(df.format(cajaP)+"%");
        }
        
        { // Utilidad neta
            Cuenta c = GetCuentaName.getCuentaName(rep.getOtros(), "Utilidad neta");
            double totalC = getUtilidadNeta(rep);
            double cajaP = (totalC*100)/totalO;
            txtUtilidadNeta.setText("$"+totalC);
            lblUtilidadNeta.setText(df.format(cajaP)+"%");
        }
        {//Activo circulante
            Cuenta c = GetCuentaName.getCuentaName(rep.getOcultas(), "Activo circulante");
            double totalC = getActivoCirculante(rep);
            double cajaP = (totalC*100)/totalActivos;
            txtActivocirculante.setText("$"+totalC);
            lblActivoCirculante.setText(df.format(cajaP)+"%");           
        }
        
        {//Activo fijo
            Cuenta c = GetCuentaName.getCuentaName(rep.getOcultas(), "Activo fijo");
            double totalC = getActivoFijo(rep);
            double cajaP = (totalC*100)/totalActivos;
            txtActivoFijo.setText("$"+totalC);
            lblActivoFijo.setText(df.format(cajaP)+"%");
        }
        
        {//Activo diferido
            Cuenta c = GetCuentaName.getCuentaName(rep.getOcultas(), "Activo diferido");
            double totalC = getActivoDiferido(rep);
            double cajaP = (totalC*100)/totalActivos;
            txtActivoDiferido.setText("$"+totalC);
            lblActivoDiferido.setText(df.format(cajaP)+"%");
        }
        
        {//Pasivo circulante
            Cuenta c = GetCuentaName.getCuentaName(rep.getOcultas(), "Pasivo circulante");
            double totalC = getPasivoCirculante(rep);
            double cajaP = (totalC*100)/totalP;
            txtPasivoCirculante.setText("$"+totalC);
            lblPasivoCirculante.setText(df.format(cajaP)+"%");
        }
        
        {//Pasivo fijo
            Cuenta c = GetCuentaName.getCuentaName(rep.getOcultas(), "Pasivo fijo");
            double totalC = getPasivoFijo(rep);
            double cajaP = (totalC*100)/totalP;
            txtPasivoFijo.setText("$"+totalC);
            lblPasivoFijo.setText(df.format(cajaP)+"%");
        }
        
        {//Total activos
            txtTotalActivo.setText("$"+rep.getTotalActivos());
            lblTotalActivo.setText("100%");
        }
        
        {//Total pasivos
            double totalC = rep.getTotalPasivos();
            double cajaP = (totalC*100)/totalActivos;
            txtTotalPasivo.setText("$"+totalC);
            lblTotalPasivo.setText(df.format(cajaP)+"%");
        }       
        
        {//Total capital
            double totalC = rep.getTotalOtros();
            double cajaP = (totalC*100)/totalActivos;
            txtTotalCapital.setText("$"+totalC);
            lblTotalCapital.setText(df.format(cajaP)+"%");
        }
        
    }
    
    
    private double getUtilidadNeta(Reporte r){
        Cuenta v = GetCuentaName.getCuentaName(r.getOtros(), "Ventas");
        Cuenta cv = GetCuentaName.getCuentaName(r.getOtros(), "Costo de ventas");
        Cuenta gv = GetCuentaName.getCuentaName(r.getOtros(), "Gastos de ventas");
        Cuenta ga = GetCuentaName.getCuentaName(r.getOtros(), "Gastos de administracion");
        Cuenta gf = GetCuentaName.getCuentaName(r.getOtros(), "Gastos financieros");
        Cuenta og = GetCuentaName.getCuentaName(r.getOtros(), "Otros gastos");
        Cuenta pf = GetCuentaName.getCuentaName(r.getOtros(), "Productos financieros");
        Cuenta op = GetCuentaName.getCuentaName(r.getOtros(), "Otros productos");
        
        double un = (cv.getTotal(true)+gv.getTotal(true)+
                ga.getTotal(true)+gf.getTotal(true)+og.getTotal(true));
        un=v.getTotal(true)-un;
        un=(pf.getTotal(true)+op.getTotal(true))+un;
        return un;
    }
    
    private double getActivoCirculante (Reporte r){
        Cuenta ca = GetCuentaName.getCuentaName(r.getActivos(), "Caja");
        Cuenta ba = GetCuentaName.getCuentaName(r.getActivos(), "Bancos");
        Cuenta al = GetCuentaName.getCuentaName(r.getActivos(), "Almacen");
        Cuenta cl = GetCuentaName.getCuentaName(r.getActivos(), "Clientes");
        Cuenta de = GetCuentaName.getCuentaName(r.getActivos(), "Deudores");
        Cuenta dc = GetCuentaName.getCuentaName(r.getActivos(), "Documentos por cobrar");
        
        double t = (ca.getTotal(false)+ba.getTotal(false)+al.getTotal(false)+cl.getTotal(false)+de.getTotal(false)+dc.getTotal(false));
        return t;
    }
    
    private double getActivoFijo (Reporte r){
        Cuenta te = GetCuentaName.getCuentaName(r.getActivos(), "Terrenos");
        Cuenta ed = GetCuentaName.getCuentaName(r.getActivos(), "Edificios");
        Cuenta mo = GetCuentaName.getCuentaName(r.getActivos(), "Mobiliario");
        Cuenta er = GetCuentaName.getCuentaName(r.getActivos(), "Equipo de reparto");
        Cuenta et = GetCuentaName.getCuentaName(r.getActivos(), "Equipo de transporte");
        Cuenta ec = GetCuentaName.getCuentaName(r.getActivos(), "Equipo de computo");
        
        double t = (te.getTotal(false)+ed.getTotal(false)+mo.getTotal(false)+er.getTotal(false)+et.getTotal(false)+ec.getTotal(false));
        return t;
    }
    
    private double getActivoDiferido (Reporte r){
        Cuenta go = GetCuentaName.getCuentaName(r.getActivos(), "Gastos de organizacion");
        Cuenta gi = GetCuentaName.getCuentaName(r.getActivos(), "Gastos de instalacion");
        
        double t = (go.getTotal(false)+gi.getTotal(false));
        return t;
    }
    
    private double getPasivoCirculante (Reporte r){
        Cuenta pr = GetCuentaName.getCuentaName(r.getPasivos(), "Proovedores");
        Cuenta ac = GetCuentaName.getCuentaName(r.getPasivos(), "Acreedores");
        Cuenta dp = GetCuentaName.getCuentaName(r.getPasivos(), "Documentos por pagar");
        
        double t = (pr.getTotal(true)+ac.getTotal(true)+dp.getTotal(true));
        return t;
        
    }
    
    private double getPasivoFijo (Reporte r){
        Cuenta ah = GetCuentaName.getCuentaName(r.getPasivos(), "Acreedores hipotecarios");
        Cuenta dpl = GetCuentaName.getCuentaName(r.getPasivos(), "Documentos por pagar largo plazo");
        
        double t = (ah.getTotal(true)+dpl.getTotal(true));
        return t;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel6 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtCaja = new javax.swing.JTextField();
        lblCaja = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtBancos = new javax.swing.JTextField();
        lblBancos = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtAlmacen = new javax.swing.JTextField();
        lblAlmacen = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtClientes = new javax.swing.JTextField();
        lblClientes = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtDeudores = new javax.swing.JTextField();
        lblDeudores = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtDocumentosporCobrar = new javax.swing.JTextField();
        lblDocumentosporcobrar = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        txtActivocirculante = new javax.swing.JTextField();
        lblActivoCirculante = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel45 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtTerrenos = new javax.swing.JTextField();
        lblTerrenos = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtEdificios = new javax.swing.JTextField();
        lblEdificios = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtMobiliario = new javax.swing.JTextField();
        lblMobiliario = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtEquipodeReparto = new javax.swing.JTextField();
        lblEquipodeReparto = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtEquipodeTransporte = new javax.swing.JTextField();
        lblEquipodeTransporte = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        txtEquipodeComputo = new javax.swing.JTextField();
        lblEquipodeComputo = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        txtActivoFijo = new javax.swing.JTextField();
        lblActivoFijo = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel53 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtGastosdeInstalacion = new javax.swing.JTextField();
        lblGastosdeInstalacion = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtGastosdeOrganizacion = new javax.swing.JTextField();
        lblGastosdeOrganizacion = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        txtActivoDiferido = new javax.swing.JTextField();
        lblActivoDiferido = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtTotalActivo = new javax.swing.JTextField();
        lblTotalActivo = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel25 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jLabel58 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        txtProovedores = new javax.swing.JTextField();
        lblProovedores = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        txtAcreedores = new javax.swing.JTextField();
        lblAcreedores = new javax.swing.JLabel();
        jLabel28 = new javax.swing.JLabel();
        txtDocumentosporPagar = new javax.swing.JTextField();
        lblDocumentosporPagar = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        txtPasivoCirculante = new javax.swing.JTextField();
        lblPasivoCirculante = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jLabel36 = new javax.swing.JLabel();
        jLabel63 = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        txtAcreedoresHipotecarios = new javax.swing.JTextField();
        lblAcreedoresHipotecarios = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        txtDocumentosLargoPlazo = new javax.swing.JTextField();
        lblDocumentosLargoPlazo = new javax.swing.JLabel();
        jLabel34 = new javax.swing.JLabel();
        txtPasivoFijo = new javax.swing.JTextField();
        lblPasivoFijo = new javax.swing.JLabel();
        jLabel32 = new javax.swing.JLabel();
        txtTotalPasivo = new javax.swing.JTextField();
        lblTotalPasivo = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel68 = new javax.swing.JLabel();
        txtCapitalSocal = new javax.swing.JTextField();
        lblCapitalSocial = new javax.swing.JLabel();
        jLabel69 = new javax.swing.JLabel();
        txtUtilidadNeta = new javax.swing.JTextField();
        lblUtilidadNeta = new javax.swing.JLabel();
        jLabel70 = new javax.swing.JLabel();
        txtTotalCapital = new javax.swing.JTextField();
        lblTotalCapital = new javax.swing.JLabel();

        setBackground(new java.awt.Color(204, 255, 204));

        jPanel6.setBackground(new java.awt.Color(102, 204, 255));

        jButton1.setBackground(new java.awt.Color(51, 51, 255));
        jButton1.setText("Regresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel6.add(jButton1);

        getContentPane().add(jPanel6, java.awt.BorderLayout.SOUTH);

        jPanel1.setLayout(new java.awt.GridLayout(1, 2));

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Activo"));
        jPanel2.setLayout(new java.awt.GridLayout(21, 3));

        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel16.setText("CIRCULANTE");
        jPanel2.add(jLabel16);
        jPanel2.add(jLabel22);
        jPanel2.add(jLabel37);

        jLabel1.setText("Caja");
        jPanel2.add(jLabel1);

        txtCaja.setBackground(new java.awt.Color(102, 204, 255));
        txtCaja.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtCaja.setText("0.00");
        txtCaja.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCajaActionPerformed(evt);
            }
        });
        jPanel2.add(txtCaja);

        lblCaja.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCaja.setText("jLabel38");
        jPanel2.add(lblCaja);

        jLabel2.setText("Bancos");
        jPanel2.add(jLabel2);

        txtBancos.setBackground(new java.awt.Color(102, 204, 255));
        txtBancos.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtBancos.setText("0.00");
        jPanel2.add(txtBancos);

        lblBancos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblBancos.setText("jLabel39");
        jPanel2.add(lblBancos);

        jLabel3.setText("Almacén");
        jPanel2.add(jLabel3);

        txtAlmacen.setBackground(new java.awt.Color(102, 204, 255));
        txtAlmacen.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtAlmacen.setText("0.00");
        jPanel2.add(txtAlmacen);

        lblAlmacen.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAlmacen.setText("jLabel40");
        jPanel2.add(lblAlmacen);

        jLabel4.setText("Clientes");
        jPanel2.add(jLabel4);

        txtClientes.setBackground(new java.awt.Color(102, 204, 255));
        txtClientes.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtClientes.setText("0.00");
        txtClientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtClientesActionPerformed(evt);
            }
        });
        jPanel2.add(txtClientes);

        lblClientes.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblClientes.setText("jLabel41");
        jPanel2.add(lblClientes);

        jLabel5.setText("Deudores");
        jPanel2.add(jLabel5);

        txtDeudores.setBackground(new java.awt.Color(102, 204, 255));
        txtDeudores.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtDeudores.setText("0.00");
        jPanel2.add(txtDeudores);

        lblDeudores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDeudores.setText("jLabel42");
        jPanel2.add(lblDeudores);

        jLabel6.setText("Documentos por cobrar");
        jPanel2.add(jLabel6);

        txtDocumentosporCobrar.setBackground(new java.awt.Color(102, 204, 255));
        txtDocumentosporCobrar.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtDocumentosporCobrar.setText("0.00");
        jPanel2.add(txtDocumentosporCobrar);

        lblDocumentosporcobrar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDocumentosporcobrar.setText("jLabel43");
        jPanel2.add(lblDocumentosporcobrar);

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel17.setText("Total de circulante");
        jPanel2.add(jLabel17);

        txtActivocirculante.setBackground(new java.awt.Color(102, 204, 255));
        txtActivocirculante.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtActivocirculante.setText("0.00");
        txtActivocirculante.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtActivocirculanteActionPerformed(evt);
            }
        });
        jPanel2.add(txtActivocirculante);

        lblActivoCirculante.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblActivoCirculante.setText("jLabel44");
        jPanel2.add(lblActivoCirculante);

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel18.setText("FIJO");
        jPanel2.add(jLabel18);
        jPanel2.add(jLabel23);
        jPanel2.add(jLabel45);

        jLabel7.setText("Terrenos");
        jPanel2.add(jLabel7);

        txtTerrenos.setBackground(new java.awt.Color(102, 204, 255));
        txtTerrenos.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTerrenos.setText("0.00");
        jPanel2.add(txtTerrenos);

        lblTerrenos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTerrenos.setText("jLabel46");
        jPanel2.add(lblTerrenos);

        jLabel8.setText("Edificios");
        jPanel2.add(jLabel8);

        txtEdificios.setBackground(new java.awt.Color(102, 204, 255));
        txtEdificios.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtEdificios.setText("0.00");
        jPanel2.add(txtEdificios);

        lblEdificios.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEdificios.setText("jLabel47");
        jPanel2.add(lblEdificios);

        jLabel9.setText("Mobiliario");
        jPanel2.add(jLabel9);

        txtMobiliario.setBackground(new java.awt.Color(102, 204, 255));
        txtMobiliario.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtMobiliario.setText("0.00");
        jPanel2.add(txtMobiliario);

        lblMobiliario.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMobiliario.setText("jLabel48");
        jPanel2.add(lblMobiliario);

        jLabel10.setText("Equipo de reparto");
        jPanel2.add(jLabel10);

        txtEquipodeReparto.setBackground(new java.awt.Color(102, 204, 255));
        txtEquipodeReparto.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtEquipodeReparto.setText("0.00");
        jPanel2.add(txtEquipodeReparto);

        lblEquipodeReparto.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEquipodeReparto.setText("jLabel49");
        jPanel2.add(lblEquipodeReparto);

        jLabel11.setText("Equipo de transporte");
        jPanel2.add(jLabel11);

        txtEquipodeTransporte.setBackground(new java.awt.Color(102, 204, 255));
        txtEquipodeTransporte.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtEquipodeTransporte.setText("0.00");
        jPanel2.add(txtEquipodeTransporte);

        lblEquipodeTransporte.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEquipodeTransporte.setText("jLabel50");
        jPanel2.add(lblEquipodeTransporte);

        jLabel12.setText("Equipo de cómputo");
        jPanel2.add(jLabel12);

        txtEquipodeComputo.setBackground(new java.awt.Color(102, 204, 255));
        txtEquipodeComputo.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtEquipodeComputo.setText("0.00");
        jPanel2.add(txtEquipodeComputo);

        lblEquipodeComputo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblEquipodeComputo.setText("jLabel51");
        jPanel2.add(lblEquipodeComputo);

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel19.setText("Total de fijo");
        jPanel2.add(jLabel19);

        txtActivoFijo.setBackground(new java.awt.Color(102, 204, 255));
        txtActivoFijo.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtActivoFijo.setText("0.00");
        jPanel2.add(txtActivoFijo);

        lblActivoFijo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblActivoFijo.setText("jLabel52");
        jPanel2.add(lblActivoFijo);

        jLabel20.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel20.setText("DIFERIDO");
        jPanel2.add(jLabel20);
        jPanel2.add(jLabel24);
        jPanel2.add(jLabel53);

        jLabel13.setText("Gastos de instalación");
        jPanel2.add(jLabel13);

        txtGastosdeInstalacion.setBackground(new java.awt.Color(102, 204, 255));
        txtGastosdeInstalacion.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtGastosdeInstalacion.setText("0.00");
        jPanel2.add(txtGastosdeInstalacion);

        lblGastosdeInstalacion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGastosdeInstalacion.setText("jLabel54");
        jPanel2.add(lblGastosdeInstalacion);

        jLabel14.setText("Gastos de organización");
        jPanel2.add(jLabel14);

        txtGastosdeOrganizacion.setBackground(new java.awt.Color(102, 204, 255));
        txtGastosdeOrganizacion.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtGastosdeOrganizacion.setText("0.00");
        jPanel2.add(txtGastosdeOrganizacion);

        lblGastosdeOrganizacion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGastosdeOrganizacion.setText("jLabel55");
        jPanel2.add(lblGastosdeOrganizacion);

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel21.setText("Total de diferido");
        jPanel2.add(jLabel21);

        txtActivoDiferido.setBackground(new java.awt.Color(102, 204, 255));
        txtActivoDiferido.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtActivoDiferido.setText("0.00");
        jPanel2.add(txtActivoDiferido);

        lblActivoDiferido.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblActivoDiferido.setText("jLabel56");
        jPanel2.add(lblActivoDiferido);

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel15.setText("Total de activo");
        jPanel2.add(jLabel15);

        txtTotalActivo.setBackground(new java.awt.Color(102, 204, 255));
        txtTotalActivo.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTotalActivo.setText("0.00");
        jPanel2.add(txtTotalActivo);

        lblTotalActivo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTotalActivo.setText("jLabel57");
        jPanel2.add(lblTotalActivo);

        jPanel1.add(jPanel2);

        jPanel3.setLayout(new java.awt.GridLayout(2, 1));

        jPanel4.setBackground(new java.awt.Color(204, 204, 204));
        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder("Pasivo"));
        jPanel4.setLayout(new java.awt.GridLayout(10, 2));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel25.setText("CIRCULANTE");
        jPanel4.add(jLabel25);
        jPanel4.add(jLabel35);
        jPanel4.add(jLabel58);

        jLabel26.setText("Proovedores");
        jPanel4.add(jLabel26);

        txtProovedores.setBackground(new java.awt.Color(102, 204, 255));
        txtProovedores.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtProovedores.setText("0.00");
        jPanel4.add(txtProovedores);

        lblProovedores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblProovedores.setText("jLabel59");
        jPanel4.add(lblProovedores);

        jLabel27.setText("Acreedores");
        jPanel4.add(jLabel27);

        txtAcreedores.setBackground(new java.awt.Color(102, 204, 255));
        txtAcreedores.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtAcreedores.setText("0.00");
        jPanel4.add(txtAcreedores);

        lblAcreedores.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAcreedores.setText("jLabel60");
        jPanel4.add(lblAcreedores);

        jLabel28.setText("Documentos por pagar");
        jPanel4.add(jLabel28);

        txtDocumentosporPagar.setBackground(new java.awt.Color(102, 204, 255));
        txtDocumentosporPagar.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtDocumentosporPagar.setText("0.00");
        txtDocumentosporPagar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtDocumentosporPagarActionPerformed(evt);
            }
        });
        jPanel4.add(txtDocumentosporPagar);

        lblDocumentosporPagar.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDocumentosporPagar.setText("jLabel61");
        jPanel4.add(lblDocumentosporPagar);

        jLabel33.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel33.setText("Total de circulante");
        jPanel4.add(jLabel33);

        txtPasivoCirculante.setBackground(new java.awt.Color(102, 204, 255));
        txtPasivoCirculante.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtPasivoCirculante.setText("0.00");
        jPanel4.add(txtPasivoCirculante);

        lblPasivoCirculante.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPasivoCirculante.setText("jLabel62");
        jPanel4.add(lblPasivoCirculante);

        jLabel29.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel29.setText("FIJO");
        jPanel4.add(jLabel29);
        jPanel4.add(jLabel36);
        jPanel4.add(jLabel63);

        jLabel30.setText("Acreedores hipotecarios");
        jPanel4.add(jLabel30);

        txtAcreedoresHipotecarios.setBackground(new java.awt.Color(102, 204, 255));
        txtAcreedoresHipotecarios.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtAcreedoresHipotecarios.setText("0.00");
        jPanel4.add(txtAcreedoresHipotecarios);

        lblAcreedoresHipotecarios.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblAcreedoresHipotecarios.setText("jLabel64");
        jPanel4.add(lblAcreedoresHipotecarios);

        jLabel31.setText("Documentos por pagar largo plazo");
        jPanel4.add(jLabel31);

        txtDocumentosLargoPlazo.setBackground(new java.awt.Color(102, 204, 255));
        txtDocumentosLargoPlazo.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtDocumentosLargoPlazo.setText("0.00");
        jPanel4.add(txtDocumentosLargoPlazo);

        lblDocumentosLargoPlazo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblDocumentosLargoPlazo.setText("jLabel65");
        jPanel4.add(lblDocumentosLargoPlazo);

        jLabel34.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel34.setText("Total de fijo");
        jPanel4.add(jLabel34);

        txtPasivoFijo.setBackground(new java.awt.Color(102, 204, 255));
        txtPasivoFijo.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtPasivoFijo.setText("0.00");
        jPanel4.add(txtPasivoFijo);

        lblPasivoFijo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPasivoFijo.setText("jLabel66");
        jPanel4.add(lblPasivoFijo);

        jLabel32.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel32.setText("Total de pasivo");
        jPanel4.add(jLabel32);

        txtTotalPasivo.setBackground(new java.awt.Color(102, 204, 255));
        txtTotalPasivo.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTotalPasivo.setText("0.00");
        jPanel4.add(txtTotalPasivo);

        lblTotalPasivo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTotalPasivo.setText("jLabel67");
        jPanel4.add(lblTotalPasivo);

        jPanel3.add(jPanel4);

        jPanel5.setBackground(new java.awt.Color(204, 204, 204));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("Capital"));
        jPanel5.setLayout(new java.awt.GridLayout(3, 3));

        jLabel68.setText("Capital Social");
        jPanel5.add(jLabel68);

        txtCapitalSocal.setBackground(new java.awt.Color(102, 204, 255));
        txtCapitalSocal.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtCapitalSocal.setText("0.00");
        jPanel5.add(txtCapitalSocal);

        lblCapitalSocial.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCapitalSocial.setText("jLabel71");
        jPanel5.add(lblCapitalSocial);

        jLabel69.setText("Utilidad Neta");
        jPanel5.add(jLabel69);

        txtUtilidadNeta.setBackground(new java.awt.Color(102, 204, 255));
        txtUtilidadNeta.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtUtilidadNeta.setText("0.00");
        jPanel5.add(txtUtilidadNeta);

        lblUtilidadNeta.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblUtilidadNeta.setText("jLabel72");
        jPanel5.add(lblUtilidadNeta);

        jLabel70.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel70.setText("Total de capital");
        jPanel5.add(jLabel70);

        txtTotalCapital.setBackground(new java.awt.Color(102, 204, 255));
        txtTotalCapital.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTotalCapital.setText("0.00");
        txtTotalCapital.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTotalCapitalActionPerformed(evt);
            }
        });
        jPanel5.add(txtTotalCapital);

        lblTotalCapital.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTotalCapital.setText("jLabel73");
        jPanel5.add(lblTotalCapital);

        jPanel3.add(jPanel5);

        jPanel1.add(jPanel3);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents
    private void txtCajaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCajaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCajaActionPerformed

    private void txtActivocirculanteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtActivocirculanteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtActivocirculanteActionPerformed

    private void txtClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtClientesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtClientesActionPerformed

    private void txtDocumentosporPagarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtDocumentosporPagarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDocumentosporPagarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtTotalCapitalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTotalCapitalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTotalCapitalActionPerformed

    
  
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel45;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel53;
    private javax.swing.JLabel jLabel58;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel63;
    private javax.swing.JLabel jLabel68;
    private javax.swing.JLabel jLabel69;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel70;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JLabel lblAcreedores;
    private javax.swing.JLabel lblAcreedoresHipotecarios;
    private javax.swing.JLabel lblActivoCirculante;
    private javax.swing.JLabel lblActivoDiferido;
    private javax.swing.JLabel lblActivoFijo;
    private javax.swing.JLabel lblAlmacen;
    private javax.swing.JLabel lblBancos;
    private javax.swing.JLabel lblCaja;
    private javax.swing.JLabel lblCapitalSocial;
    private javax.swing.JLabel lblClientes;
    private javax.swing.JLabel lblDeudores;
    private javax.swing.JLabel lblDocumentosLargoPlazo;
    private javax.swing.JLabel lblDocumentosporPagar;
    private javax.swing.JLabel lblDocumentosporcobrar;
    private javax.swing.JLabel lblEdificios;
    private javax.swing.JLabel lblEquipodeComputo;
    private javax.swing.JLabel lblEquipodeReparto;
    private javax.swing.JLabel lblEquipodeTransporte;
    private javax.swing.JLabel lblGastosdeInstalacion;
    private javax.swing.JLabel lblGastosdeOrganizacion;
    private javax.swing.JLabel lblMobiliario;
    private javax.swing.JLabel lblPasivoCirculante;
    private javax.swing.JLabel lblPasivoFijo;
    private javax.swing.JLabel lblProovedores;
    private javax.swing.JLabel lblTerrenos;
    private javax.swing.JLabel lblTotalActivo;
    private javax.swing.JLabel lblTotalCapital;
    private javax.swing.JLabel lblTotalPasivo;
    private javax.swing.JLabel lblUtilidadNeta;
    private javax.swing.JTextField txtAcreedores;
    private javax.swing.JTextField txtAcreedoresHipotecarios;
    private javax.swing.JTextField txtActivoDiferido;
    private javax.swing.JTextField txtActivoFijo;
    private javax.swing.JTextField txtActivocirculante;
    private javax.swing.JTextField txtAlmacen;
    private javax.swing.JTextField txtBancos;
    private javax.swing.JTextField txtCaja;
    private javax.swing.JTextField txtCapitalSocal;
    private javax.swing.JTextField txtClientes;
    private javax.swing.JTextField txtDeudores;
    private javax.swing.JTextField txtDocumentosLargoPlazo;
    private javax.swing.JTextField txtDocumentosporCobrar;
    private javax.swing.JTextField txtDocumentosporPagar;
    private javax.swing.JTextField txtEdificios;
    private javax.swing.JTextField txtEquipodeComputo;
    private javax.swing.JTextField txtEquipodeReparto;
    private javax.swing.JTextField txtEquipodeTransporte;
    private javax.swing.JTextField txtGastosdeInstalacion;
    private javax.swing.JTextField txtGastosdeOrganizacion;
    private javax.swing.JTextField txtMobiliario;
    private javax.swing.JTextField txtPasivoCirculante;
    private javax.swing.JTextField txtPasivoFijo;
    private javax.swing.JTextField txtProovedores;
    private javax.swing.JTextField txtTerrenos;
    private javax.swing.JTextField txtTotalActivo;
    private javax.swing.JTextField txtTotalCapital;
    private javax.swing.JTextField txtTotalPasivo;
    private javax.swing.JTextField txtUtilidadNeta;
    // End of variables declaration//GEN-END:variables
}
