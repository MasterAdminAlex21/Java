/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinanzas;
import proyectofinanzas.Principal;
import proyectofinanzas.beans.Cuenta;
import proyectofinanzas.beans.GetCuentaName;
import proyectofinanzas.beans.Reporte;
/**
 *
 * @author Plata
 */
public class EstadoResultados extends javax.swing.JFrame {
    /**
     * Creates new form EstadoResultados
     */
    public EstadoResultados(Reporte rep) {
        
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Estado de Resultados");
        initComponents();
        setReporte(rep);
    }

    private Reporte rep;
    
    public final void setReporte(Reporte rep){
        this.rep=rep;
        
        double totalOtros = rep.getTotalOtros();
        double totalO = rep.getTotalOtros();
        txtVentas.setText("$"+totalOtros);
        lblVentas.setText("100%");
        
        
        { // Costo de ventas
            Cuenta c = GetCuentaName.getCuentaName(rep.getOtros(), "Costo de ventas");
            double totalC = c.getTotal();
            double cuentaP = (totalC*100)/totalOtros;
            txtCostodeventas.setText("$"+totalC);
            lblCostodeventas.setText(cuentaP+"%");
        }
        
         { // Gastos de ventas
            Cuenta c = GetCuentaName.getCuentaName(rep.getOtros(), "Gastos de ventas");
            double totalC = c.getTotal();
            double cuentaP = (totalC*100)/totalOtros;
            txtGastosdeventas.setText("$"+totalC);
            lblGastosdeventas.setText(cuentaP+"%");
        }
         
          { // Gatos de administracion
            Cuenta c = GetCuentaName.getCuentaName(rep.getOtros(), "Gastos de administracion");
            double totalC = c.getTotal();
            double cuentaP = (totalC*100)/totalOtros;
            txtGastosdeadministracion.setText("$"+totalC);
            lblGastosdeadministracion.setText(cuentaP+"%");
        }
          
         { // Gastos financieros
            Cuenta c = GetCuentaName.getCuentaName(rep.getOtros(), "Gastos financieros");
            double totalC = c.getTotal();
            double cuentaP = (totalC*100)/totalOtros;
            txtGastosfinancieros.setText("$"+totalC);
            lblGastosfinancieros.setText(cuentaP+"%");
        }
        
         { // Otros gastos
            Cuenta c = GetCuentaName.getCuentaName(rep.getOtros(), "Otros gastos");
            double totalC = c.getTotal();
            double cuentaP = (totalC*100)/totalOtros;
            txtOtrosgastos.setText("$"+totalC);
            lblOtrosgastos.setText(cuentaP+"%");
        }
         
         { // Prosuctos financieros
            Cuenta c = GetCuentaName.getCuentaName(rep.getOtros(), "Productos financieros");
            double totalC = c.getTotal();
            double cuentaP = (totalC*100)/totalOtros;
            txtProductosfinancieros.setText("$"+totalC);
            lblProductosfinancieros.setText(cuentaP+"%");
        }
         
         { // Otros productos
            Cuenta c = GetCuentaName.getCuentaName(rep.getOtros(), "Otros productos");
            double totalC = c.getTotal();
            double cuentaP = (totalC*100)/totalOtros;
            txtOtrosproductos.setText("$"+totalC);
            lblOtrosproductos.setText(cuentaP+"%");
        }
        
        { // Utilidad neta
            Cuenta c = GetCuentaName.getCuentaName(rep.getOtros(), "Utilidad neta");
            txtUtilidadneta.setText("$"+getUtilidadNeta(rep));
            double cuentaP = (100*getUtilidadNeta(rep))/totalOtros;
            lblUtilidadneta.setText(cuentaP+"%");
        }
        
        { // Utilidad bruta
            txtUtilidadbruta.setText("$"+getUtilidadBruta(rep));
            double cuentaP = (100*getUtilidadBruta(rep))/totalOtros;
            lblUtilidadbruta.setText(cuentaP+"%");
        }
        
        { // Utilidad antes de impuestos
            txtUtilidadantesdeimpuestos.setText("$"+getUtilidadAntesdeImpuestos(rep));
            double cuentaP = (100*getUtilidadAntesdeImpuestos(rep))/totalOtros;
            lblUtilidadantesdeimpuestos.setText(cuentaP+"%");
        }
         
        
    }
   
    
     private double getUtilidadNeta(Reporte r){
        double utanimp = getUtilidadAntesdeImpuestos(r);
        double un = utanimp-(utanimp*.36)-(utanimp*.1);
        return un;
    }
     
     private double getUtilidadBruta(Reporte r){
        Cuenta v = GetCuentaName.getCuentaName(r.getOtros(), "Ventas");
        Cuenta cv = GetCuentaName.getCuentaName(r.getOtros(), "Costo de ventas");
        Cuenta gv = GetCuentaName.getCuentaName(r.getOtros(), "Gastos de ventas");
        
        double ub = (v.getTotal(true)-cv.getTotal(true)-gv.getTotal(true));
        
        return ub;
     }
    
     private double getUtilidadAntesdeImpuestos(Reporte r){
        Cuenta v = GetCuentaName.getCuentaName(r.getOtros(), "Ventas");
        Cuenta cv = GetCuentaName.getCuentaName(r.getOtros(), "Costo de ventas");
        Cuenta gv = GetCuentaName.getCuentaName(r.getOtros(), "Gastos de ventas");
        Cuenta ga = GetCuentaName.getCuentaName(r.getOtros(), "Gastos de administracion");
        Cuenta gf = GetCuentaName.getCuentaName(r.getOtros(), "Gastos financieros");
        Cuenta og = GetCuentaName.getCuentaName(r.getOtros(), "Otros gastos");
        Cuenta pf = GetCuentaName.getCuentaName(r.getOtros(), "Productos financieros");
        Cuenta op = GetCuentaName.getCuentaName(r.getOtros(), "Otros productos");
        
        double un = (cv.getTotal(true)+gv.getTotal(true)+ga.getTotal(true)+gf.getTotal(true)+og.getTotal(true));
        un=v.getTotal(true)-un;
        un=(pf.getTotal(true)+op.getTotal(true))+un;
        return un;
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtVentas = new javax.swing.JTextField();
        lblVentas = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtCostodeventas = new javax.swing.JTextField();
        lblCostodeventas = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtGastosdeventas = new javax.swing.JTextField();
        lblGastosdeventas = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtUtilidadbruta = new javax.swing.JTextField();
        lblUtilidadbruta = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtGastosdeadministracion = new javax.swing.JTextField();
        lblGastosdeadministracion = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtGastosfinancieros = new javax.swing.JTextField();
        lblGastosfinancieros = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtOtrosgastos = new javax.swing.JTextField();
        lblOtrosgastos = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtProductosfinancieros = new javax.swing.JTextField();
        lblProductosfinancieros = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtOtrosproductos = new javax.swing.JTextField();
        lblOtrosproductos = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtUtilidadantesdeimpuestos = new javax.swing.JTextField();
        lblUtilidadantesdeimpuestos = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtUtilidadneta = new javax.swing.JTextField();
        lblUtilidadneta = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();

        jPanel1.setLayout(new java.awt.GridLayout(14, 2));

        jLabel1.setText("Ventas");
        jPanel1.add(jLabel1);

        txtVentas.setEditable(false);
        txtVentas.setBackground(new java.awt.Color(153, 204, 255));
        txtVentas.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtVentas.setText("jTextField1");
        txtVentas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtVentasActionPerformed(evt);
            }
        });
        jPanel1.add(txtVentas);

        lblVentas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblVentas.setText("jLabel18");
        jPanel1.add(lblVentas);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setText("menos");
        jPanel1.add(jLabel10);
        jPanel1.add(jLabel19);
        jPanel1.add(jLabel16);

        jLabel2.setText("Costo de ventas");
        jPanel1.add(jLabel2);

        txtCostodeventas.setEditable(false);
        txtCostodeventas.setBackground(new java.awt.Color(153, 204, 255));
        txtCostodeventas.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtCostodeventas.setText("jTextField2");
        jPanel1.add(txtCostodeventas);

        lblCostodeventas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblCostodeventas.setText("jLabel20");
        jPanel1.add(lblCostodeventas);

        jLabel3.setText("Gastos de ventas");
        jPanel1.add(jLabel3);

        txtGastosdeventas.setEditable(false);
        txtGastosdeventas.setBackground(new java.awt.Color(153, 204, 255));
        txtGastosdeventas.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtGastosdeventas.setText("jTextField3");
        jPanel1.add(txtGastosdeventas);

        lblGastosdeventas.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGastosdeventas.setText("jLabel21");
        jPanel1.add(lblGastosdeventas);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setText("Utilidad bruta");
        jPanel1.add(jLabel11);

        txtUtilidadbruta.setEditable(false);
        txtUtilidadbruta.setBackground(new java.awt.Color(153, 204, 255));
        txtUtilidadbruta.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtUtilidadbruta.setText("jTextField4");
        jPanel1.add(txtUtilidadbruta);

        lblUtilidadbruta.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblUtilidadbruta.setText("jLabel22");
        jPanel1.add(lblUtilidadbruta);

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel12.setText("menos");
        jPanel1.add(jLabel12);
        jPanel1.add(jLabel23);
        jPanel1.add(jLabel17);

        jLabel4.setText("Gastos de administración");
        jPanel1.add(jLabel4);

        txtGastosdeadministracion.setEditable(false);
        txtGastosdeadministracion.setBackground(new java.awt.Color(153, 204, 255));
        txtGastosdeadministracion.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtGastosdeadministracion.setText("jTextField5");
        jPanel1.add(txtGastosdeadministracion);

        lblGastosdeadministracion.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGastosdeadministracion.setText("jLabel24");
        jPanel1.add(lblGastosdeadministracion);

        jLabel5.setText("Gastos financieros");
        jPanel1.add(jLabel5);

        txtGastosfinancieros.setEditable(false);
        txtGastosfinancieros.setBackground(new java.awt.Color(153, 204, 255));
        txtGastosfinancieros.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtGastosfinancieros.setText("jTextField6");
        jPanel1.add(txtGastosfinancieros);

        lblGastosfinancieros.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblGastosfinancieros.setText("jLabel25");
        jPanel1.add(lblGastosfinancieros);

        jLabel6.setText("Otros gastos");
        jPanel1.add(jLabel6);

        txtOtrosgastos.setEditable(false);
        txtOtrosgastos.setBackground(new java.awt.Color(153, 204, 255));
        txtOtrosgastos.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtOtrosgastos.setText("jTextField7");
        jPanel1.add(txtOtrosgastos);

        lblOtrosgastos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblOtrosgastos.setText("jLabel26");
        jPanel1.add(lblOtrosgastos);

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel13.setText("mas");
        jPanel1.add(jLabel13);
        jPanel1.add(jLabel27);
        jPanel1.add(jLabel15);

        jLabel7.setText("Productos financieros");
        jPanel1.add(jLabel7);

        txtProductosfinancieros.setEditable(false);
        txtProductosfinancieros.setBackground(new java.awt.Color(153, 204, 255));
        txtProductosfinancieros.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtProductosfinancieros.setText("jTextField8");
        jPanel1.add(txtProductosfinancieros);

        lblProductosfinancieros.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblProductosfinancieros.setText("jLabel28");
        jPanel1.add(lblProductosfinancieros);

        jLabel8.setText("Otros productos");
        jPanel1.add(jLabel8);

        txtOtrosproductos.setEditable(false);
        txtOtrosproductos.setBackground(new java.awt.Color(153, 204, 255));
        txtOtrosproductos.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtOtrosproductos.setText("jTextField9");
        jPanel1.add(txtOtrosproductos);

        lblOtrosproductos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblOtrosproductos.setText("jLabel29");
        jPanel1.add(lblOtrosproductos);

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel14.setText("Utilidad antes de impuestos");
        jPanel1.add(jLabel14);

        txtUtilidadantesdeimpuestos.setEditable(false);
        txtUtilidadantesdeimpuestos.setBackground(new java.awt.Color(153, 204, 255));
        txtUtilidadantesdeimpuestos.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtUtilidadantesdeimpuestos.setText("jTextField10");
        jPanel1.add(txtUtilidadantesdeimpuestos);

        lblUtilidadantesdeimpuestos.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblUtilidadantesdeimpuestos.setText("jLabel30");
        jPanel1.add(lblUtilidadantesdeimpuestos);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("Utilidad neta");
        jPanel1.add(jLabel9);

        txtUtilidadneta.setEditable(false);
        txtUtilidadneta.setBackground(new java.awt.Color(153, 204, 255));
        txtUtilidadneta.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtUtilidadneta.setText("jTextField11");
        txtUtilidadneta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtUtilidadnetaActionPerformed(evt);
            }
        });
        jPanel1.add(txtUtilidadneta);

        lblUtilidadneta.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblUtilidadneta.setText("jLabel31");
        jPanel1.add(lblUtilidadneta);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        jButton1.setBackground(new java.awt.Color(51, 51, 255));
        jButton1.setText("Regresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);

        getContentPane().add(jPanel2, java.awt.BorderLayout.SOUTH);
    }// </editor-fold>//GEN-END:initComponents

    private void txtUtilidadnetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtUtilidadnetaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtUtilidadnetaActionPerformed

    private void txtVentasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtVentasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtVentasActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblCostodeventas;
    private javax.swing.JLabel lblGastosdeadministracion;
    private javax.swing.JLabel lblGastosdeventas;
    private javax.swing.JLabel lblGastosfinancieros;
    private javax.swing.JLabel lblOtrosgastos;
    private javax.swing.JLabel lblOtrosproductos;
    private javax.swing.JLabel lblProductosfinancieros;
    private javax.swing.JLabel lblUtilidadantesdeimpuestos;
    private javax.swing.JLabel lblUtilidadbruta;
    private javax.swing.JLabel lblUtilidadneta;
    private javax.swing.JLabel lblVentas;
    private javax.swing.JTextField txtCostodeventas;
    private javax.swing.JTextField txtGastosdeadministracion;
    private javax.swing.JTextField txtGastosdeventas;
    private javax.swing.JTextField txtGastosfinancieros;
    private javax.swing.JTextField txtOtrosgastos;
    private javax.swing.JTextField txtOtrosproductos;
    private javax.swing.JTextField txtProductosfinancieros;
    private javax.swing.JTextField txtUtilidadantesdeimpuestos;
    private javax.swing.JTextField txtUtilidadbruta;
    private javax.swing.JTextField txtUtilidadneta;
    private javax.swing.JTextField txtVentas;
    // End of variables declaration//GEN-END:variables
}
