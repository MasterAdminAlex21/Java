/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectofinanzas;

import proyectofinanzas.beans.Cuenta;
import proyectofinanzas.beans.GetCuentaName;
import proyectofinanzas.beans.Reporte;

/**
 *
 * @author Plata
 */
public class EstadoOA extends javax.swing.JFrame {

    /**
     * Creates new form EstadoOA
     */
    public EstadoOA(Reporte rep) {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setTitle("Estado de origen y aplicacion");
        initComponents();
        calcula(rep);
    }

    
    private void calcula(Reporte rep){
            Cuenta dcaja = GetCuentaName.getCuentaName(rep.getDiferencias(), "DCaja");
            Cuenta dbancos = GetCuentaName.getCuentaName(rep.getDiferencias(), "DBancos");
            Cuenta dalmacen = GetCuentaName.getCuentaName(rep.getDiferencias(), "DAlmacen");
            Cuenta dclientes = GetCuentaName.getCuentaName(rep.getDiferencias(), "DClientes");
            Cuenta ddeudores = GetCuentaName.getCuentaName(rep.getDiferencias(), "DDeudores");
            Cuenta ddocumentosporcobrar = GetCuentaName.getCuentaName(rep.getDiferencias(), "DDocumentos por pagar");
            Cuenta dterrenos = GetCuentaName.getCuentaName(rep.getDiferencias(), "DTerrenos");
            Cuenta dedificios = GetCuentaName.getCuentaName(rep.getDiferencias(), "DEdificios");
            Cuenta dmobiliario = GetCuentaName.getCuentaName(rep.getDiferencias(), "DMobiliario");
            Cuenta dequipodereparto = GetCuentaName.getCuentaName(rep.getDiferencias(), "DEquipo de reparto");
            Cuenta dequipodetransporte = GetCuentaName.getCuentaName(rep.getDiferencias(), "DEquipo de transporte");
            Cuenta dequipodecomputo = GetCuentaName.getCuentaName(rep.getDiferencias(), "DEquipo de computo");
            Cuenta dgastosdeinstalacion = GetCuentaName.getCuentaName(rep.getDiferencias(), "DGastos de instalacion");
            Cuenta dgastosdeorganizacion = GetCuentaName.getCuentaName(rep.getDiferencias(), "DGastos de organizacion");
            
            Cuenta dproovedores = GetCuentaName.getCuentaName(rep.getDiferencias(), "DProovedores");
            Cuenta dacreedores = GetCuentaName.getCuentaName(rep.getDiferencias(), "DAcreedores");
            Cuenta ddocumentosporpagar = GetCuentaName.getCuentaName(rep.getDiferencias(), "DDocumentos por pagar");
            Cuenta dacreedoreshipotecarios = GetCuentaName.getCuentaName(rep.getDiferencias(), "DAcreedores hipotecarios");
            Cuenta ddocumentosporpagarlargoplazo = GetCuentaName.getCuentaName(rep.getDiferencias(), "DDocumentos por pagar largo plazo");
           
            Cuenta dcapitalsocial = GetCuentaName.getCuentaName(rep.getDiferencias(), "DCapital social");
            Cuenta dutilidadneta = GetCuentaName.getCuentaName(rep.getDiferencias(), "DUtilidad neta");
            
            if (dcaja.getTotal()>0)
                txtcajaa.setText(""+ dcaja.getTotal());
            else
                txtcajao.setText(""+ dcaja.getTotal());
            
            if (dbancos.getTotal()>0)
                txtbancosa.setText(""+ dbancos.getTotal());
            else
                txtbancoso.setText(""+ dbancos.getTotal());
            
            if (dalmacen.getTotal()>0)
                txtalmacena.setText(""+ dalmacen.getTotal());
            else
                txtalmaceno.setText(""+ dalmacen.getTotal());
            
            if (dclientes.getTotal()>0)
                txtclientesa.setText(""+ dclientes.getTotal());
            else
                txtclienteso.setText(""+ dclientes.getTotal());
            
            if (ddeudores.getTotal()>0)
                txtdeudoresa.setText(""+ ddeudores.getTotal());
            else
                txtdeudoreso.setText(""+ ddeudores.getTotal());
            
            if (ddocumentosporcobrar.getTotal()>0)
                txtdocumentosporcobrara.setText(""+ ddocumentosporcobrar.getTotal());
            else
                txtdocumentosporcobraro.setText(""+ ddocumentosporcobrar.getTotal());
            
            if (dterrenos.getTotal()>0)
                txtterrenosa.setText(""+ dterrenos.getTotal());
            else
                txtterrenoso.setText(""+ dterrenos.getTotal());
            
            if (dedificios.getTotal()>0)
                txtedificiosa.setText(""+ dedificios.getTotal());
            else
                txtedificioso.setText(""+ dedificios.getTotal());
            
            if (dmobiliario.getTotal()>0)
                txtmobiliarioa.setText(""+ dmobiliario.getTotal());
            else
                txtmobiliarioo.setText(""+ dmobiliario.getTotal());
            
            if (dequipodereparto.getTotal()>0)
                txtequipoderepartoa.setText(""+ dequipodereparto.getTotal());
            else
                txtequipoderepartoo.setText(""+ dequipodereparto.getTotal());
            
            if (dequipodetransporte.getTotal()>0)
                txtequipodetransportea.setText(""+ dequipodetransporte.getTotal());
            else
                txtequipodetransporteo.setText(""+ dequipodetransporte.getTotal());
            
            if (dequipodecomputo.getTotal()>0)
                txtequipodecomputoa.setText(""+ dequipodecomputo.getTotal());
            else
                txtequipodecomputoo.setText(""+ dequipodecomputo.getTotal());
            
            if (dgastosdeinstalacion.getTotal()>0)
                txtgastosdeinstalaciona.setText(""+ dgastosdeinstalacion.getTotal());
            else
                txtgastosdeinstalaciono.setText(""+ dgastosdeinstalacion.getTotal());
            
            if (dgastosdeorganizacion.getTotal()>0)
                txtgastosdeorganizaciona.setText(""+ dgastosdeorganizacion.getTotal());
            else
                txtgastosdeorganizaciono.setText(""+ dgastosdeorganizacion.getTotal());
            
            if (dproovedores.getTotal()>0)
                txtproovedoreso.setText(""+ dproovedores.getTotal());
            else
                txtproovedoresa.setText(""+ dproovedores.getTotal());
            
            if (dacreedores.getTotal()>0)
                txtacreedoreso.setText(""+ dacreedores.getTotal());
            else
                txtacreedoresa.setText(""+ dacreedores.getTotal());
            
            if (ddocumentosporpagar.getTotal()>0)
                txtdocumentosporpagaro.setText(""+ ddocumentosporpagar.getTotal());
            else
                txtdocumentosporpagara.setText(""+ ddocumentosporpagar.getTotal());
            
            if (dacreedoreshipotecarios.getTotal()>0)
                txtacreedoreshipotecarioso.setText(""+ dacreedoreshipotecarios.getTotal());
            else
                txtacreedoreshipotecariosa.setText(""+ dacreedoreshipotecarios.getTotal());
            
            if (ddocumentosporpagarlargoplazo.getTotal()>0)
                txtdocumentoslargoplazoo.setText(""+ ddocumentosporpagarlargoplazo.getTotal());
            else
                txtdocumentoslargoplazoa.setText(""+ ddocumentosporpagarlargoplazo.getTotal());
            
            if (dcapitalsocial.getTotal()>0)
                txtcapitalsocialo.setText(""+ dcapitalsocial.getTotal());
            else
                txtcapitalsociala.setText(""+ dcapitalsocial.getTotal());
            
            if (dutilidadneta.getTotal()>0)
                txtutilidadnetao.setText(""+ dutilidadneta.getTotal());
            else
                txtutilidadnetaa.setText(""+ dutilidadneta.getTotal());
            
            txtsumao.setText(""+(Double.parseDouble(txtcajao.getText())+Double.parseDouble(txtbancoso.getText())+Double.parseDouble(txtalmaceno.getText())+Double.parseDouble(txtclienteso.getText())+Double.parseDouble(txtdeudoreso.getText())+Double.parseDouble(txtdocumentosporcobraro.getText())+Double.parseDouble(txtterrenoso.getText())+Double.parseDouble(txtedificioso.getText())+Double.parseDouble(txtmobiliarioo.getText())+Double.parseDouble(txtequipoderepartoo.getText())+Double.parseDouble(txtequipodetransporteo.getText())+Double.parseDouble(txtequipodecomputoo.getText())+Double.parseDouble(txtgastosdeinstalaciono.getText())+Double.parseDouble(txtgastosdeorganizaciono.getText())+Double.parseDouble(txtproovedoreso.getText())+Double.parseDouble(txtacreedoreso.getText())+Double.parseDouble(txtdocumentosporpagaro.getText())+Double.parseDouble(txtacreedoreshipotecarioso.getText())+Double.parseDouble(txtdocumentoslargoplazoo.getText())+Double.parseDouble(txtcapitalsocialo.getText())+Double.parseDouble(txtutilidadnetao.getText())));
            txtsumaa.setText(""+(Double.parseDouble(txtcajaa.getText())+Double.parseDouble(txtbancosa.getText())+Double.parseDouble(txtalmacena.getText())+Double.parseDouble(txtclientesa.getText())+Double.parseDouble(txtdeudoresa.getText())+Double.parseDouble(txtdocumentosporcobrara.getText())+Double.parseDouble(txtterrenosa.getText())+Double.parseDouble(txtedificiosa.getText())+Double.parseDouble(txtmobiliarioa.getText())+Double.parseDouble(txtequipoderepartoa.getText())+Double.parseDouble(txtequipodetransportea.getText())+Double.parseDouble(txtequipodecomputoa.getText())+Double.parseDouble(txtgastosdeinstalaciona.getText())+Double.parseDouble(txtgastosdeorganizaciona.getText())+Double.parseDouble(txtproovedoresa.getText())+Double.parseDouble(txtacreedoresa.getText())+Double.parseDouble(txtdocumentosporpagara.getText())+Double.parseDouble(txtacreedoreshipotecariosa.getText())+Double.parseDouble(txtdocumentoslargoplazoa.getText())+Double.parseDouble(txtcapitalsociala.getText())+Double.parseDouble(txtutilidadnetaa.getText())));
            
            
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel25 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtcajao = new javax.swing.JTextField();
        txtcajaa = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtbancoso = new javax.swing.JTextField();
        txtbancosa = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtalmaceno = new javax.swing.JTextField();
        txtalmacena = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtclienteso = new javax.swing.JTextField();
        txtclientesa = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtdeudoreso = new javax.swing.JTextField();
        txtdeudoresa = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtdocumentosporcobraro = new javax.swing.JTextField();
        txtdocumentosporcobrara = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtterrenoso = new javax.swing.JTextField();
        txtterrenosa = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtedificioso = new javax.swing.JTextField();
        txtedificiosa = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtmobiliarioo = new javax.swing.JTextField();
        txtmobiliarioa = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtequipodetransporteo = new javax.swing.JTextField();
        txtequipodetransportea = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtequipoderepartoo = new javax.swing.JTextField();
        txtequipoderepartoa = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtequipodecomputoo = new javax.swing.JTextField();
        txtequipodecomputoa = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtgastosdeinstalaciono = new javax.swing.JTextField();
        txtgastosdeinstalaciona = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txtgastosdeorganizaciono = new javax.swing.JTextField();
        txtgastosdeorganizaciona = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtproovedoreso = new javax.swing.JTextField();
        txtproovedoresa = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        txtacreedoreso = new javax.swing.JTextField();
        txtacreedoresa = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        txtdocumentosporpagaro = new javax.swing.JTextField();
        txtdocumentosporpagara = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        txtacreedoreshipotecarioso = new javax.swing.JTextField();
        txtacreedoreshipotecariosa = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        txtdocumentoslargoplazoo = new javax.swing.JTextField();
        txtdocumentoslargoplazoa = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        txtcapitalsocialo = new javax.swing.JTextField();
        txtcapitalsociala = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        txtutilidadnetao = new javax.swing.JTextField();
        txtutilidadnetaa = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        txtsumao = new javax.swing.JTextField();
        txtsumaa = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();

        jLabel25.setText("jLabel25");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));
        jPanel1.setLayout(new java.awt.GridLayout(23, 3));

        jLabel1.setText("Cuenta");
        jPanel1.add(jLabel1);

        jLabel24.setText("Origen");
        jPanel1.add(jLabel24);

        jLabel26.setText("Aplicación");
        jPanel1.add(jLabel26);

        jLabel2.setText("Caja");
        jPanel1.add(jLabel2);

        txtcajao.setBackground(new java.awt.Color(153, 204, 255));
        txtcajao.setText("0");
        jPanel1.add(txtcajao);

        txtcajaa.setText("0");
        jPanel1.add(txtcajaa);

        jLabel3.setText("Bancos");
        jPanel1.add(jLabel3);

        txtbancoso.setText("0");
        jPanel1.add(txtbancoso);

        txtbancosa.setBackground(new java.awt.Color(153, 204, 255));
        txtbancosa.setText("0");
        jPanel1.add(txtbancosa);

        jLabel4.setText("Almacen");
        jPanel1.add(jLabel4);

        txtalmaceno.setBackground(new java.awt.Color(153, 204, 255));
        txtalmaceno.setText("0");
        jPanel1.add(txtalmaceno);

        txtalmacena.setText("0");
        jPanel1.add(txtalmacena);

        jLabel5.setText("Clientes");
        jPanel1.add(jLabel5);

        txtclienteso.setText("0");
        jPanel1.add(txtclienteso);

        txtclientesa.setBackground(new java.awt.Color(153, 204, 255));
        txtclientesa.setText("0");
        jPanel1.add(txtclientesa);

        jLabel6.setText("Deudores");
        jPanel1.add(jLabel6);

        txtdeudoreso.setBackground(new java.awt.Color(153, 204, 255));
        txtdeudoreso.setText("0");
        jPanel1.add(txtdeudoreso);

        txtdeudoresa.setText("0");
        jPanel1.add(txtdeudoresa);

        jLabel7.setText("Documentos por cobrar");
        jPanel1.add(jLabel7);

        txtdocumentosporcobraro.setText("0");
        jPanel1.add(txtdocumentosporcobraro);

        txtdocumentosporcobrara.setBackground(new java.awt.Color(153, 204, 255));
        txtdocumentosporcobrara.setText("0");
        jPanel1.add(txtdocumentosporcobrara);

        jLabel8.setText("Terrenos");
        jPanel1.add(jLabel8);

        txtterrenoso.setBackground(new java.awt.Color(153, 204, 255));
        txtterrenoso.setText("0");
        jPanel1.add(txtterrenoso);

        txtterrenosa.setText("0");
        jPanel1.add(txtterrenosa);

        jLabel9.setText("Edificios");
        jPanel1.add(jLabel9);

        txtedificioso.setText("0");
        jPanel1.add(txtedificioso);

        txtedificiosa.setBackground(new java.awt.Color(153, 204, 255));
        txtedificiosa.setText("0");
        jPanel1.add(txtedificiosa);

        jLabel10.setText("Mobiliario");
        jPanel1.add(jLabel10);

        txtmobiliarioo.setBackground(new java.awt.Color(153, 204, 255));
        txtmobiliarioo.setText("0");
        jPanel1.add(txtmobiliarioo);

        txtmobiliarioa.setText("0");
        jPanel1.add(txtmobiliarioa);

        jLabel11.setText("Equipo de transporte");
        jPanel1.add(jLabel11);

        txtequipodetransporteo.setText("0");
        jPanel1.add(txtequipodetransporteo);

        txtequipodetransportea.setBackground(new java.awt.Color(153, 204, 255));
        txtequipodetransportea.setText("0");
        jPanel1.add(txtequipodetransportea);

        jLabel12.setText("Equipo de reparto");
        jPanel1.add(jLabel12);

        txtequipoderepartoo.setBackground(new java.awt.Color(153, 204, 255));
        txtequipoderepartoo.setText("0");
        jPanel1.add(txtequipoderepartoo);

        txtequipoderepartoa.setText("0");
        jPanel1.add(txtequipoderepartoa);

        jLabel13.setText("Equipo de computo");
        jPanel1.add(jLabel13);

        txtequipodecomputoo.setText("0");
        jPanel1.add(txtequipodecomputoo);

        txtequipodecomputoa.setBackground(new java.awt.Color(153, 204, 255));
        txtequipodecomputoa.setText("0");
        jPanel1.add(txtequipodecomputoa);

        jLabel14.setText("Gastos de instalacion");
        jPanel1.add(jLabel14);

        txtgastosdeinstalaciono.setBackground(new java.awt.Color(153, 204, 255));
        txtgastosdeinstalaciono.setText("0");
        jPanel1.add(txtgastosdeinstalaciono);

        txtgastosdeinstalaciona.setText("0");
        jPanel1.add(txtgastosdeinstalaciona);

        jLabel15.setText("Gastos de organizacion");
        jPanel1.add(jLabel15);

        txtgastosdeorganizaciono.setText("0");
        jPanel1.add(txtgastosdeorganizaciono);

        txtgastosdeorganizaciona.setBackground(new java.awt.Color(153, 204, 255));
        txtgastosdeorganizaciona.setText("0");
        jPanel1.add(txtgastosdeorganizaciona);

        jLabel16.setText("Proovedores");
        jPanel1.add(jLabel16);

        txtproovedoreso.setBackground(new java.awt.Color(153, 204, 255));
        txtproovedoreso.setText("0");
        jPanel1.add(txtproovedoreso);

        txtproovedoresa.setText("0");
        jPanel1.add(txtproovedoresa);

        jLabel17.setText("Acreedores");
        jPanel1.add(jLabel17);

        txtacreedoreso.setText("0");
        jPanel1.add(txtacreedoreso);

        txtacreedoresa.setBackground(new java.awt.Color(153, 204, 255));
        txtacreedoresa.setText("0");
        jPanel1.add(txtacreedoresa);

        jLabel18.setText("Documentos por pagar");
        jPanel1.add(jLabel18);

        txtdocumentosporpagaro.setBackground(new java.awt.Color(153, 204, 255));
        txtdocumentosporpagaro.setText("0");
        jPanel1.add(txtdocumentosporpagaro);

        txtdocumentosporpagara.setText("0");
        jPanel1.add(txtdocumentosporpagara);

        jLabel19.setText("Acreedores hipotecarios");
        jPanel1.add(jLabel19);

        txtacreedoreshipotecarioso.setText("0");
        jPanel1.add(txtacreedoreshipotecarioso);

        txtacreedoreshipotecariosa.setBackground(new java.awt.Color(153, 204, 255));
        txtacreedoreshipotecariosa.setText("0");
        jPanel1.add(txtacreedoreshipotecariosa);

        jLabel20.setText("Documentos por pagar largo plazo");
        jPanel1.add(jLabel20);

        txtdocumentoslargoplazoo.setBackground(new java.awt.Color(153, 204, 255));
        txtdocumentoslargoplazoo.setText("0");
        jPanel1.add(txtdocumentoslargoplazoo);

        txtdocumentoslargoplazoa.setText("0");
        jPanel1.add(txtdocumentoslargoplazoa);

        jLabel21.setText("Capital social");
        jPanel1.add(jLabel21);

        txtcapitalsocialo.setText("0");
        jPanel1.add(txtcapitalsocialo);

        txtcapitalsociala.setBackground(new java.awt.Color(153, 204, 255));
        txtcapitalsociala.setText("0");
        jPanel1.add(txtcapitalsociala);

        jLabel22.setText("Utilidad neta");
        jPanel1.add(jLabel22);

        txtutilidadnetao.setBackground(new java.awt.Color(153, 204, 255));
        txtutilidadnetao.setText("0");
        jPanel1.add(txtutilidadnetao);

        txtutilidadnetaa.setText("0");
        jPanel1.add(txtutilidadnetaa);

        jLabel23.setText("Suma");
        jPanel1.add(jLabel23);

        txtsumao.setText("0");
        jPanel1.add(txtsumao);

        txtsumaa.setBackground(new java.awt.Color(153, 204, 255));
        txtsumaa.setText("0");
        jPanel1.add(txtsumaa);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        jPanel2.setBackground(new java.awt.Color(153, 204, 255));

        jButton1.setBackground(new java.awt.Color(0, 51, 204));
        jButton1.setText("Regresar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1);

        getContentPane().add(jPanel2, java.awt.BorderLayout.SOUTH);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        setVisible(false);
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JTextField txtacreedoresa;
    private javax.swing.JTextField txtacreedoreshipotecariosa;
    private javax.swing.JTextField txtacreedoreshipotecarioso;
    private javax.swing.JTextField txtacreedoreso;
    private javax.swing.JTextField txtalmacena;
    private javax.swing.JTextField txtalmaceno;
    private javax.swing.JTextField txtbancosa;
    private javax.swing.JTextField txtbancoso;
    private javax.swing.JTextField txtcajaa;
    private javax.swing.JTextField txtcajao;
    private javax.swing.JTextField txtcapitalsociala;
    private javax.swing.JTextField txtcapitalsocialo;
    private javax.swing.JTextField txtclientesa;
    private javax.swing.JTextField txtclienteso;
    private javax.swing.JTextField txtdeudoresa;
    private javax.swing.JTextField txtdeudoreso;
    private javax.swing.JTextField txtdocumentoslargoplazoa;
    private javax.swing.JTextField txtdocumentoslargoplazoo;
    private javax.swing.JTextField txtdocumentosporcobrara;
    private javax.swing.JTextField txtdocumentosporcobraro;
    private javax.swing.JTextField txtdocumentosporpagara;
    private javax.swing.JTextField txtdocumentosporpagaro;
    private javax.swing.JTextField txtedificiosa;
    private javax.swing.JTextField txtedificioso;
    private javax.swing.JTextField txtequipodecomputoa;
    private javax.swing.JTextField txtequipodecomputoo;
    private javax.swing.JTextField txtequipoderepartoa;
    private javax.swing.JTextField txtequipoderepartoo;
    private javax.swing.JTextField txtequipodetransportea;
    private javax.swing.JTextField txtequipodetransporteo;
    private javax.swing.JTextField txtgastosdeinstalaciona;
    private javax.swing.JTextField txtgastosdeinstalaciono;
    private javax.swing.JTextField txtgastosdeorganizaciona;
    private javax.swing.JTextField txtgastosdeorganizaciono;
    private javax.swing.JTextField txtmobiliarioa;
    private javax.swing.JTextField txtmobiliarioo;
    private javax.swing.JTextField txtproovedoresa;
    private javax.swing.JTextField txtproovedoreso;
    private javax.swing.JTextField txtsumaa;
    private javax.swing.JTextField txtsumao;
    private javax.swing.JTextField txtterrenosa;
    private javax.swing.JTextField txtterrenoso;
    private javax.swing.JTextField txtutilidadnetaa;
    private javax.swing.JTextField txtutilidadnetao;
    // End of variables declaration//GEN-END:variables
}
